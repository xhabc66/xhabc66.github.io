#include<iostream>
using namespace std;
struct endline{}eline;
inline ostream& operator<<(ostream& out, endline){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
int main(){
	cout << "" << eline << "                  |\\" << eline << "                  | \\" << eline << "                  |  \\" << eline << "                  |   \\" << eline << "                  |    \\ o" << eline << "                  |     V|\\" << eline << "                  |     /_\\___" << eline << "~~~~~~~~~~~~~~~~~>O~~~~|      |~~~~~~~~~~~~|" << eline << "                              |            |" << eline << "                              |            |" << eline << "                              |____________|" << eline;
}
