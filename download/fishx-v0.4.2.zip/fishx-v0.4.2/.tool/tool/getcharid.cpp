#include<bits/stdc++.h>
using namespace std;

int main()
{
    system("stty raw");
    char c;
    while(c=getchar()){
        //if(c=='^C')break;
        cout<<(int)c<<' ';
    }
    system("stty cooked");
}