## 开发者模式
### 开启方法
- 在启动命令上加入 `-admin` 选项
- 在菜单输入 `del`
### 命令列表
- `level type:int num:int`:将编号为 `type` 的附魔更新为 `num`
- `fish type:int num:int`:将编号为 `type` 的鱼数量更新为 `num`
- `item type:int num:int`:将编号为 `type` 的物品数量更新为 `num`
- `money num:int`:将金币更新为 `num`
- `xp num:int`:将经验更新为 `num`
- `naijiu num:int`:将耐久更新为 `num`
- `mxy type:string`:
    - `type:add`:添加一只美西螈
    - `type:clear`:清空所有美西螈
- `time num:int`:将游戏内时间更新为 `num`
- `day num:int`:将游戏天数更新为 `num`
- `weather num:int`:将游戏天气更新为 `num`
- `quit`：退出指令