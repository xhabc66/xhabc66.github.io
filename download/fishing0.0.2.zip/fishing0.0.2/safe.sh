stty echo
stty cooked