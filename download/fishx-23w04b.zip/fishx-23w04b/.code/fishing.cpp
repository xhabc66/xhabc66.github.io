/*
* 附魔：0.钓饵 1.海之眷顾 2.力量 3.时运 4.耐久 5.经验修补 6.效率
* 鱼类：0.普通鱼 1.大鱼 2.附魔书 3.发光墨鱼 4.美西螈 5.墨鱼
*/
#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<ctime>
#include<map>
#include<algorithm>
#include<vector>
#include<cmath>
#include <functional>
using std::cin;
using std::cout;
using std::ostream;
using std::string;
using std::to_string;
using std::ifstream;
using std::ofstream;
using std::hash;
using std::setw;
using std::min;
using std::max;
using std::pair;
using std::vector;
using std::map;
inline void clear(){
	system("clear");
}
struct endline{}endl;
inline ostream& operator<<(ostream& out, endline e){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
inline char getch(){
	char c = getchar();
	if(c == 3){
		clear();
		cout << "^C" << endl;
		system("stty cooked");
		system("stty echo");
		exit(1);
	}
	if(c == 26){
		clear();
		cout << "^Z" << endl << "[1]+  Stopped                 fishing.run" << endl;
		system("stty cooked");
		system("stty echo");
		exit(1);
	}

	return c;
}
void do_nothing_void(){}
bool do_nothing_bool(){return false;}
int do_nothing_int(){return 0;}
long long do_nothing_long_long(){return 0LL;}
double do_nothing_double(){return 0.0;}

namespace variate{
	const int FULL_BROKEN_VALUE = 300;
	const int TIME_GAME_BEGIN = 480;
	const int DAY_GAME_BEGIN = 100;
	const int LEVEL_BOOK_MAX_LEVEL = 4;
	const int TIP_NUM = 8;
	const string TIPS[TIP_NUM]={
		"要达到一定等级之后天线才会解码成功噢",
		"猜猜你下次看到这条tip是什么时候？",
		"为什么只有字符画渲染？\033[9m因为xhabc66不会别的（逃\033[0m",
		"fishx里也有季节，但只有2个季节：春夏秋和冬(bushi",
		"我是不会告诉你附魔最高只有30级的   啊？你怎么知道的？！",
		"众所周知，附魔书算鱼（逃",
		"如果有BUG可以洛谷私信xhabc66",
		"为什么每一次版本更新的内容这么少？因为xhabc66很喜欢重构代码"
	};
	const int LEVEL_NUM = 7;
	const int MAX_LEVEL = 30;
	const string LEVEL_NAME[LEVEL_NUM] = {"钓饵","海之眷顾","力量","时运","耐久","经验修补","效率"};
	const bool HIDE_LEVEL[LEVEL_NUM] = {0, 0, 0, 0, 0, 1, 0};
	const int LEVEL_HEIGHT[LEVEL_NUM] = {3, 3, 1, 1, 1, 0, 1};
	const int LEVEL[LEVEL_NUM][2][MAX_LEVEL+1]={{
							{100, 100,  90,  80,  80,  70,  60,  50,  50,  40,  40,  40,  40,  40,  40,  35,  30,  25,  20,  10,   8,   7,   6,   5,   4,   3,   3,   2,   1,   1,   0},
							{ 50,  40,  40,  40,  30,  30,  30,  30,  20,  20,  10,   9,   7,   5,   4,   4,   3,   3,   3,   3,   3,   3,   2,   2,   2,   2,   1,   1,   1,   0,   0}},{
							{ 20,  20,  20,  30,  30,  40,  40,  40,  50,  50,  55,  60,  60,  60,  70,  70,  80,  80,  90, 100, 105, 110, 120, 130, 135, 140, 145, 150, 160, 180, 200},
							{ 10,  12,  15,  15,  20,  20,  25,  30,  35,  40,  40,  40,  45,  50,  60,  60,  60,  70,  80,  85,  85,  90,  95, 100, 100, 100, 100, 100, 100, 100, 200}},{
							{ 32,  24,  20,  16,  13,  10,   9,   8,   7,   7,   6,   6,   5,   5,   4,   4,   3,   3,   3,   2,   2,   2,   2,   1,   1,   1,   1,   1,   1,   1,   0},
							{ 32,  24,  20,  16,  13,  10,   9,   8,   7,   7,   6,   6,   5,   5,   4,   4,   3,   3,   3,   2,   2,   2,   2,   1,   1,   1,   1,   1,   1,   1,   0}},{
							{ 20,  21,  22,  23,  24,  25,  26,  27,  28,  30,  32,  33,  34,  35,  36,  38,  40,  42,  44,  46,  48,  50,  52,  54,  56,  58,  60,  62,  63,  64,  65},
							{ 20,  21,  22,  23,  24,  25,  26,  27,  28,  30,  32,  33,  34,  35,  36,  38,  40,  42,  44,  46,  48,  50,  52,  54,  56,  58,  60,  62,  63,  64,  65}},{
							{ 12,  10,   8,   7,   6,   6,   5,   5,   5,   5,   5,   4,   4,   4,   4,   3,   3,   3,   2,   2,   2,   2,   2,   2,   2,   1,   1,   1,   1,   1,   0},
							{  6,   6,   5,   5,   4,   4,   3,   3,   2,   2,   2,   2,   2,   1,   1,   1,   1,   1,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0}},{
							{  0,   1,   2,   2,   3,   3,   3,   4,   4,   4,   5,   5,   5,   6,   6,   7,   7,   8,   8,   9,   9,  10,  10,  11,  12,  13,  14,  15,  16,  18,  20},
							{  0,   0,   0,   1,   1,   1,   2,   2,   2,   3,   3,   3,   4,   4,   4,   5,   5,   5,   6,   6,   7,   7,   8,   8,   9,   9,  10,  10,  11,  13,  15}},{
							{  1,   1,   1,   1,   1,   2,   2,   2,   3,   3,   3,   4,   4,   4,   5,   5,   5,   6,   6,   6,   6,   7,   7,   7,   7,   8,   8,   8,   9,   9,  10},
							{  1,   1,   1,   1,   1,   2,   2,   2,   3,   3,   3,   4,   4,   4,   5,   5,   5,   6,   6,   6,   6,   7,   7,   7,   7,   8,   8,   8,   9,   9,  10}}};
	const int FISH_NUM = 6;
	const string FISH_NAME[FISH_NUM] = {"普通鱼","大鱼","附魔书","发光墨鱼","美西螈","墨鱼"};
	const string FISH_COLOR[FISH_NUM] = {"\033[0m", "\033[1m", "\033[0m", "\033[1;33m", "\033[1;35m", "\033[1;30m"};
	const int FISH_TYPE[FISH_NUM] = {0, 0, 2, 1, 2, 1};
	const int FISH_PRIZE[FISH_NUM] = {1, 2, 0, 0, 0, 0};
	const int FISH_TURN[FISH_NUM] = {-1, -1, -1, 0, -1, 1};
	const int ITEM_NUM = 3;
	const string ITEM_NAME[ITEM_NUM] = {"发光墨囊","墨囊","书"};
	const int ITEM_SELL[ITEM_NUM] = {80, 15, 10};	
	const int ITEM_BUY[ITEM_NUM] = {120, -1, -1};
	
	
	string username;
	long long money = 0;
	int level[LEVEL_NUM] = {};
	int fishNum[FISH_NUM] = {};
	int item[ITEM_NUM] = {};
	vector<int> mxy;
	int lightlast = 0;
	int xp = 0;
	int naijiu = FULL_BROKEN_VALUE;
	int statu = 0;
	int book[LEVEL_NUM][LEVEL_BOOK_MAX_LEVEL]={};
	int gametime = TIME_GAME_BEGIN;
	int gameday = DAY_GAME_BEGIN;
	int weather = 0;
	
	int stime = 1;
	long long ltime = 0, left = 0;
	bool auto_fishing = false;
	int spead = 2;
	int time0;
	vector<int> mxytime;
	int rain_water[15][2]={{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7},{rand()%46,rand()%7}};
	
	bool is_update = true;
	bool is_admin = false;

	inline int lv(){
		int allHeight = 0;
		int sumHeight = 0;
		for(int i=0;i<LEVEL_NUM;i++)
			allHeight += LEVEL_HEIGHT[i],
			sumHeight += LEVEL_HEIGHT[i]*level[i];
		return round(1.0*sumHeight/allHeight);
	}
	inline int get_level(){
		int returnlevel;
		do{
			returnlevel = rand()%LEVEL_NUM;
		}while(HIDE_LEVEL[returnlevel]);
		return returnlevel;
	}
	inline int get_fishsum(){
		int sum=0;
		for(int i=0;i<FISH_NUM;i++)
			sum+=fishNum[i];
		return sum;
	}
}
string to_stringf(double d){
	return to_string((int)d) + "." + to_string(((int)(d * 10)) % 10);
}
bool issymbol(char type){
	string symbols = "({[<`~!@#$%^&*-_ +=|;:.?>]})\"'\\/";
	size_t found = symbols.find(type);
	if(found != string::npos){
		return true;
	}else{
		return false;
	}
}
inline int readint(string str, int maxvalue = 2147483647){
	int s = 0;
	while(true){
		char d = getch();
		if(isdigit(d)){
			s *= 10;
			s += d ^ '0';
			if(s > maxvalue){
				s = maxvalue;
			}
			cout << "\r          \r" << str << s;
			cout.flush();
		}else if(d == 127){
			s /= 10;
			cout << "\r          \r" << str << s;
			cout.flush();
		}else if(d == '\r'){
			break;
		}
	}
	return s;
}
inline int getint(string s,int b = 0){
	if(s == "")return b;
	int a=0;
	for(auto v:s)
		if('0'<=v && v <='9')
			a=a*10+v-'0';
		else return b;
	return a;
}
inline bool each(char a,string s)
{
	for(auto v:s)if(v==a)return true;
	return false;
}
inline string getline(string &ans, bool b = false){
	cout.flush();
	ans = "";
	char a = 0;
	while((a = getch()) != '\r'){
		if(issymbol(a) || isdigit(a) || islower(a) || isupper(a)){
			ans += a;
			if(b){
				cout << a;
				cout.flush();
			}
		}
		if(a == 127 && ans.length()){
			ans.pop_back();
			if(b){
				cout << "\b \b";
				cout.flush();
			}
		}
	}
	cout << endl;
	return ans;
}
inline unsigned long long to_hash(string s){
	return static_cast<unsigned long long>(hash<string>{}(s));
}
namespace color{
	string NONE = "\033[m";
	string RED = "\033[0;32;31m";
	string LIGHT_RED = "\033[1;31m";
	string GREEN = "\033[0;32;32m";
	string LIGHT_GREEN = "\033[1;32m";
	string BLUE = "\033[0;32;34m";
	string LIGHT_BLUE = "\033[1;34m";
	string DARY_GRAY = "\033[1;30m";
	string CYAN = "\033[0;36m";
	string LIGHT_CYAN = "\033[1;36m";
	string PURPLE = "\033[0;35m";
	string LIGHT_PURPLE = "\033[1;35m";
	string BROWN = "\033[0;33m";
	string YELLOW = "\033[1;33m";
	string LIGHT_GRAY = "\033[0;37m";
	string WHITE = "\033[1;37m";
	string SHINE = "\033[5m";       //闪烁
	string DASH = "\033[9m";        //删除线
	string QUICKSHINE = "\033[6m";  //快闪
	string FANXIAN = "\033[7m";     //反显
	string XIAOYIN = "\033[8m";     //消隐, 消失隐藏
	
}
inline void sleep(double time){
	system(((string)"sleep " + to_string(time)).c_str());
}
inline void print(string s, double time = 0.02){
	if(variate::spead == 1000){
		cout << s << endl;
	}else{
		for(char i : s){
			sleep(time / variate::spead);
			cout << i;
			cout.flush();
		}
		cout << endl;
	}
}

inline void echo(string s)
{
	system(("echo \""+s+"\"").c_str());
	cout<<endl;
}

inline void printa(string s, double time = 0.02){
	print(s + "    (按enter继续)", time);
	while(getch() != '\r');
}
namespace get_random{
	inline int random(int l, int r){
		int len = r - l;
		int re = rand() * 1.0 / RAND_MAX * len + l + 0.5;
		return re;
	}
	inline int level_rand(int type){
		return random(variate::LEVEL[type][1][variate::level[type]], variate::LEVEL[type][0][variate::level[type]]);
	}
	inline int getgiant_rand(){
		return random(9000, 10000);
	}

	bool get_normal_fish(){return false;}
	bool get_book(){
		int l=0;
		if(rand()%10<5)l=1;
		else if(rand()%5<3)l=2;
		else if(rand()%4<3)l=3;
		else l=4;
		int type=variate::get_level();
		variate::book[type][l]++;
		printa((string)"你钓到了一本"+variate::LEVEL_NAME[type]+to_string(l)+"的附魔书");
		return true;
	}
	bool get_mxy(){
		variate::mxy.push_back(0);
		variate::mxytime.push_back(time(0));
		printa("你钓到了一条美西螈");
		return true;
	}
	bool (*getfish[variate::FISH_NUM])() = {get_normal_fish, get_normal_fish, get_book, get_normal_fish, get_mxy, get_normal_fish};
	inline void get(int fishtype){
		variate::fishNum[fishtype]++;
		variate::xp++;
		if(getfish[fishtype]())return;
		else printa("你钓到了一条"+variate::FISH_NAME[fishtype]);
	}
	inline void getgiant(){
		int pri = getgiant_rand();
		variate::money += pri;
		variate::xp += 3;
		printa((string)"你钓到了一条巨型鲨鱼, 价值$" + to_string(pri) + ", 你现在有$" + to_string(variate::money));
	}
}
class base64{
	private:
		int basedecode[128];
		char baseencode[65];
		char oth;
		bool use[7];
		int ans[7];
		int tot;
		char tb(int n){
			return baseencode[n & 0x3f];
		}
		void quan(int n, int b){
			if(n >= 6){
				tot++;
				return;
			}
			for(int i = 0; i <= 4; i++){
				if(use[i]){
					continue;
				}
				use[i] = true;
				ans[n] = i;
				quan(n + 1, b);
				use[i] = false;
				if(b == tot){
					return;
				}
			}
		}
		string get_password(string s){
			size_t ha = hash<string>{}(s);
			unsigned long long  num = static_cast<unsigned long long>(ha);
			char a[6] = "aA1";
			string list = "({[<`~!@#$%^&*-_+=|;:.?>]})";
			unsigned long long n1 = num / list.length();
			unsigned long long r1 = num % list.length();
			unsigned long long n2 = n1 / (list.length() - 1);
			unsigned long long r2 = n1 % (list.length() - 1);
			unsigned long long n3 = n2 / (list.length() - 2);
			unsigned long long r3 = n2 % (list.length() - 2);
			unsigned long long n4 = n3 / 120;
			unsigned long long r4 = n3 % 120;
			a[3] = list[r1];
			list.erase(r1, 1);
			a[4] = list[r2];
			list.erase(r2, 1);
			a[5] = list[r3];
			for(int i = 0; i <= 4; i++){
				use[i] = false;
				ans[i] = 0;
			}
			ans[6] = 5;
			quan(1, r4 + 1);
			string an;
			for(int i = 1; i <= 6; i++){
				an += a[ans[i]];
			}
			return an;
		}
		void set_base(string s){
			int i = 0;
			for(int i = 0; i < 64; i++){
				baseencode[i] = '\0';
			}
			for(int i = 0; i < 128; i++){
				basedecode[i] = '\0';
			}
			oth = s[5];
			for(int j = 0; j < 5; j++){
				if(isdigit(s[j])){
					for(int j = 0; j < 10; j++){
						basedecode[j + '0'] = i;
						baseencode[i++] = j + '0';
					}
				}else if(islower(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'a'] = i;
						baseencode[i++] = j + 'a';
					}
				}else if(isupper(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'A'] = i;
						baseencode[i++] = j + 'A';
					}
				}else{
					basedecode[s[j]] = i;
					baseencode[i++] = s[j];
				}
			}
		}
	public:
		base64(string s){
			set_base(s);
		}
		base64(string s, bool salt){
			if(salt){
				set_base(get_password(s + "add_salt"));
			}else{
				set_base(get_password(s + "no_salt"));
			}
		}
		string decode(string in){//jiema
			string ans;
			for(int i = 0; i < in.length(); i += 4){
				ans += (char)((unsigned char)basedecode[in[i]] << 2 | (unsigned char)basedecode[in[i + 1]] >> 4) & 0xff;
				if(in[i + 2] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 1]] << 4 | (unsigned char)basedecode[in[i + 2]] >> 2) & 0xff;
				}
				if(in[i + 3] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 2]] << 6 | (unsigned char)basedecode[in[i + 3]]) & 0xff;
				}
			}
			return ans;
		}
		string encode(string in){//bianma
			string ans;
			for(int i = 0; i < in.length(); i += 3){
				ans += tb(((unsigned char)in[i] >> 2));
				ans += tb(((unsigned char)in[i] << 4) | (i + 1 >= in.length() ? 0 : ((unsigned char)in[i + 1] >> 4)));
				ans += (i + 1 >= in.length()) ? oth : tb(((unsigned char)in[i + 1] << 2) | (i + 2 >= in.length() ? 0 : ((unsigned char)in[i + 2] >> 6)));
				ans += (i + 2 >= in.length()) ? oth : tb(((unsigned char)in[i + 2]));
			}
			while(ans.length() % 4){
				ans += oth;
			}
			return ans;
		}
}b1("a[0]A`"), b2("(0aA);"), b3("|a0+A-");
namespace weather{
	const string WEATHER_NAME[] = {"晴", "多云", "阴", "小雨", "中雨", "大雨"};
	const string COLD_WEATHER_NAME[] = {"晴", "多云", "阴", "小雪", "中雪", "大雪"};
	const string rain[]={   "     _____        ___________               ",
                            " ___/     \\__  __/   \\_      \\______________ ",
                            "/   \\_    /  \\/     _/    ___/\\__           \\",
                            "\\____________/\\_____________________________/"};
	const string cloud[]={  "     _____    ",
							" ___/     \\__                              ",
							"/   \\_    /  \\                             ",
							"\\____________/                             "};
	const string sun[]={    "                                           ",
							" __                                        ",
							"/  \\                                       ",
							"\\__/                                       "};
	const string moon[]={   "  _                                         ",
							" | \\                                        ",
							" |  |                                       ",
							" |_/                                        "};
	inline int getcha(int a){return round(-cos(acos(-1)*(a)/365*2)*120);}
	inline int getlight(){
		int cha=getcha(variate::gameday);
		int sunrisetime=400-cha,sunsettime=1040+cha;
		if(variate::gametime <= sunrisetime-30 || sunsettime+30 <= variate::gametime)return -1;
		else if(sunrisetime <= variate::gametime && variate::gametime <= sunsettime)return 1;
		else return 0;
	}
	inline int getweather(){return (30 <= variate::gameday && variate::gameday <= 360)?0:1;}
	inline void printweather()
	{
		if(variate::weather >= 2){
			cout<<"\033[1;30m";
			for(int i=0;i<4;i++)cout<<rain[i]<<endl;
		}else if(variate::weather == 1){
			cout<<"\033[2m";
			for(int i=0;i<4;i++)cout<<cloud[i]<<endl;
		}else if(getlight() == -1){
			cout<<color::NONE;
			for(int i=0;i<4;i++)cout<<moon[i]<<endl;
		}else if(getlight() == 1){
			cout<<color::YELLOW;
			for(int i=0;i<4;i++)cout<<sun[i]<<endl;
		}else if(getlight() == 0)for(int i=0;i<4;i++)cout<<endl;
		cout<<color::NONE;
	}
}
namespace fishing{
	const string mb_pic[]={ "                                              ",
							"                                              ",
							"                                              ",
							"                                              ",
							"                         o                    ",
							"                        /|\\                   ",
							"                        /_\\___                ",
							"~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|~~",
							"                              |            |  ",
							"                              |      >O    |  ",
							"                              |____________|  "};
	string pic[]={			"                                              ",
							"                                              ",
							"                                              ",
							"                                              ",
							"                         o                    ",
							"                        /|\\                   ",
							"                        /_\\___                ",
							"~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|~~",
							"                              |            |  ",
							"                              |      >O    |  ",
							"                              |____________|  "};
	int tipid;
	inline void init(){for(int i=0;i<11;i++)pic[i]=mb_pic[i];}
	inline bool checkfish(int i,int j){
		if(i==0&&pic[i][j]=='^')return true;
		if(i==10&&pic[i][j]=='O')return true;
		if(i<10&&pic[i][j]=='O'&&pic[i+1][j]=='^')return true;
		if(i>0 &&pic[i-1][j]=='O'&&pic[i][j]=='^')return true;
		
		
		if(i==0&&pic[i][j]=='O')return true;
		if(i==10&&pic[i][j]=='V')return true;
		if(i<10&&pic[i][j]=='V'&&pic[i+1][j]=='O')return true;
		if(i>0 &&pic[i-1][j]=='V'&&pic[i][j]=='O')return true;
		
		if(j==0&&pic[i][j]=='O')return true;
		if(j==45&&pic[i][j]=='>')return true;
		if(j<45&&pic[i][j]=='>'&&pic[i][j+1]=='O')return true;
		if(j>0 &&pic[i][j-1]=='>'&&pic[i][j]=='O')return true;

		if(j==0&&pic[i][j]=='<')return true;
		if(j==45&&pic[i][j]=='O')return true;
		if(j<45&&pic[i][j]=='O'&&pic[i][j+1]=='<')return true;
		if(j>0 &&pic[i][j-1]=='O'&&pic[i][j]=='<')return true;

		return false;
	}
	inline void showpic(double wait,string fishcolor,bool reset = false)
	{
		if((variate::gametime+(time(0)-variate::time0)*2)>=1440)variate::gameday = ((variate::gameday-1)%365+(variate::gametime+(time(0)-variate::time0)*2)/1440)+1;
		variate::gametime=(variate::gametime+(time(0)-variate::time0)*2)%1440;
		variate::time0=time(0);
		clear();
		if(rand()%15 == 0)variate::weather = min(5,max(variate::weather+rand()%3-1,0));
		weather::printweather();
		for(int i=0;i<variate::weather*5-10;i++)
			if(pic[variate::rain_water[i][1]][variate::rain_water[i][0]] == ' ')
				pic[variate::rain_water[i][1]][variate::rain_water[i][0]]='.';
		
		for(int i=0;i<11;i++){
			for(int j=0;j<46;j++)
			{
				cout<<color::NONE;
				if(pic[i][j]=='.')
					if(weather::getweather() == 0)cout<<color::BLUE<<'.';
					else cout<<color::NONE<<'*';
				else if(pic[i][j]=='~')
					if(weather::getweather() == 0)
						cout<<((weather::getlight() == 1)?"\033[1;32;36m~":"\033[1;32;34m~");
					else cout<<' ';
				else if(i==7&&(pic[i][j]=='\\'||pic[i][j]=='/'))
					if(weather::getweather() == 0)
						cout<<((weather::getlight() == 1)?(string)"\033[1;32;36m"+pic[i][j]:(string)"\033[1;32;34m"+pic[i][j]);
					else cout<<' ';
				else if(i==6&&each(pic[i+1][j],"~\\/>OV|")&&pic[i][j]==' ')
					if(weather::getweather() == 1)
						if(j!=18&&j!=35)cout<<"\033[1;32;36m-";
						else cout<<((weather::getlight() == 1)?"\033[36m~":"\033[34m~");
					else cout<<' ';
				else if(checkfish(i,j))cout<<fishcolor<<pic[i][j];
				else if(pic[i][j]=='j'&&variate::lightlast>0)cout<<color::YELLOW<<'j';
				else cout<<pic[i][j];
			}
			cout<<endl;
		}
		
		for(int i=0;i<variate::weather*5-10;i++)
			if(pic[variate::rain_water[i][1]][variate::rain_water[i][0]] == '.')
				pic[variate::rain_water[i][1]][variate::rain_water[i][0]]=' ';

		for(int i=0;i<variate::weather*5-10;i++)
		{
			variate::rain_water[i][1]++;
			if(variate::rain_water[i][1]>6)
				variate::rain_water[i][0]=rand()%46,
				variate::rain_water[i][1]=0;
		}

		cout<<"鱼："<<variate::get_fishsum()-variate::fishNum[2]<<"  天气："<<(weather::getweather() == 1?weather::COLD_WEATHER_NAME[variate::weather]:weather::WEATHER_NAME[variate::weather])<<"  时间："<<variate::gametime/60<<':'<<variate::gametime%60<<endl;
		cout<<"耐久："<<(variate::naijiu>200?"\033[1;32m":(variate::naijiu>100?"\033[1;33m":"\033[1;31m"));
		for(int i=0;i<variate::naijiu;i+=10)cout<<'=';cout<<color::NONE<<endl;
		cout<<"tip:"<<variate::TIPS[tipid]<<endl;
		system(("sleep "+to_string(wait/variate::stime)).c_str());
		clear();
		if(reset)init();
	}

	inline void per_fishing(){
		pic[5][27]=pic[5][28]=pic[5][29]=pic[5][30]=pic[5][31]=pic[5][32]=pic[5][33]=pic[5][34]='-';
		showpic(0.5/get_random::level_rand(6),"\033[0m",true);
		pic[5][26]='V';pic[4][27]=pic[3][28]=pic[2][29]=pic[1][30]=pic[0][31]='/';
		showpic(0.5/get_random::level_rand(6),"\033[0m",true);
		pic[5][26]='|';pic[4][26]=pic[3][26]=pic[2][26]=pic[1][26]=pic[0][26]='|';
		showpic(0.5/get_random::level_rand(6),"\033[0m",true);
		pic[5][24]='|';pic[4][24]=pic[3][24]=pic[2][24]=pic[1][24]=pic[0][24]='|';
		showpic(0.5/get_random::level_rand(6),"\033[0m",true);
		pic[5][24]='V';pic[4][23]=pic[3][22]=pic[2][21]=pic[1][20]=pic[0][19]='\\';
		showpic(0.5/get_random::level_rand(6),"\033[0m");
		for(int i=1;i<8;i++)
		{
			pic[i][18]='j';
			pic[i-1][18]='|';
			showpic(0.5,"\033[0m");
		}
	}

	inline void wait_fish(){
		int wait_time=get_random::level_rand(0);
		if(weather::getlight() == -1)
		{
			wait_time*=((rand()%20+140)/100.0);
			if(variate::lightlast)wait_time*=((rand()%10+45)/100.0);
		}
		for(int i=0;i<2*wait_time;(variate::weather == 2?i+=(rand()%5)/4+1:i++))showpic(0.5,"\033[0m");
		variate::lightlast--;
	}

	inline void fish_come(string fishcolor){
		pic[7][0]='O';
		showpic(0.5,fishcolor);
		for(int i=1;i<=18;i++)
		{
			pic[7][i]='O';
			pic[7][i-1]='>';
			if(i>1)pic[7][i-2]='~';
			showpic(0.5,fishcolor);
		}
		pic[7][17]='~';
		pic[6][18]='O';
		pic[7][18]='^';
		showpic(0.5,fishcolor);
	}

	inline void fish_up(string fishcolor)
	{
		pic[5][18]='O';
		pic[6][18]='^';
		pic[7][18]='~';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		for(int i=4;i>=0;i--)
		{
			pic[i][18]='O';
			pic[i+1][18]='^';
			pic[i+2][18]=' ';
			showpic(0.5/get_random::level_rand(6),fishcolor);
		}
		pic[0][18]=pic[1][18]=' ';
		pic[0][18]='O';pic[0][17]='>';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[0][18]=' ';pic[0][17]=' ';
		pic[4][23]=pic[3][22]=pic[2][21]=pic[1][20]=pic[0][19]=' ';
		pic[5][24]='|';pic[4][24]=pic[3][24]=pic[2][24]=pic[1][24]=pic[0][24]='|';
		pic[0][24]='O';pic[0][23]='>';
		showpic(0.5/get_random::level_rand(6),fishcolor,true);
		pic[5][26]='|';pic[4][26]=pic[3][26]=pic[2][26]=pic[1][26]=pic[0][26]='|';
		pic[0][26]='O';pic[0][25]='>';
		showpic(0.5/get_random::level_rand(6),fishcolor,true);
		pic[5][26]='V';pic[4][27]=pic[3][28]=pic[2][29]=pic[1][30]=pic[0][31]='/';
		pic[0][31]='O';pic[0][30]='>';
		showpic(0.5/get_random::level_rand(6),fishcolor,true);
		pic[5][27]=pic[5][28]=pic[5][29]=pic[5][30]=pic[5][31]=pic[5][32]=pic[5][33]=pic[5][34]='-';
		pic[5][35]='O';pic[4][35]='V';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[6][35]='O';pic[5][35]='V';pic[4][35]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[7][35]='O';pic[6][35]='V';pic[5][35]=' ';pic[7][34]='\\';pic[7][36]='/';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[8][35]='O';pic[7][35]='V';pic[6][35]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[9][35]='O';pic[8][35]='V';pic[7][34]=pic[7][35]=pic[7][36]='~';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[9][36]='O';pic[9][35]='>';pic[8][35]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[9][37]='O';pic[9][36]='>';pic[9][35]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		pic[9][38]='O';pic[9][37]='>';pic[9][36]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
	}

	inline void fish_run(string fishcolor){
		pic[5][18]='O';
		pic[6][18]='^';
		pic[7][18]='~';
		showpic(0.5/get_random::level_rand(6),fishcolor);
		for(int i=4;i>=0;i--)
		{
			pic[i][18]='O';
			pic[i+1][18]='^';
			pic[i+2][18]=' ';
			showpic(0.5/get_random::level_rand(6),fishcolor);
		}
		for(int i=1;i<7;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			if(i>1)pic[i-2][18]=' ';
			showpic(0.5/get_random::level_rand(6),fishcolor);
		}
		pic[7][17]='\\';pic[7][19]='/';
		for(int i=7;i<9;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			pic[i-2][18]=' ';
			showpic(0.5/get_random::level_rand(6),fishcolor);
		}
		pic[7][17]=pic[7][18]=pic[7][19]='~';
		for(int i=9;i<11;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			if(i>9)pic[i-2][18]=' ';
			showpic(0.5/get_random::level_rand(6),fishcolor);
		}
		pic[10][18]='V';pic[9][18]=' ';
		showpic(0.5/get_random::level_rand(6),fishcolor);
	}
	/*inline void fishing0(bool is_big,int fishtype){
		per_fishing();
		wait_fish();
		fish_come(variate::fish_color[fishtype]);
		fish_up(variate::fish_color[fishtype]);
		variate::cnt = 1;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		get_random::get(is_big,fishtype);
	}*/
	inline void fishing1(int fishtype){
		per_fishing();
		wait_fish();
		fish_come(variate::FISH_COLOR[fishtype]);
		if(rand()%100 < get_random::level_rand(2) || rand()%300 > variate::naijiu){fish_run(variate::FISH_COLOR[fishtype]);return;}
		fish_up(variate::FISH_COLOR[fishtype]);
		variate::naijiu = max(1,variate::naijiu - get_random::level_rand(4));
		get_random::get(fishtype);
	}
	inline void Fishing(){
		if(variate::lightlast == 0 && variate::item[0] > 0){
			print("是否使用发光墨囊加速？(t/f)");
			char ch;
			while(ch = getch())
			{
				if(ch == 't')variate::lightlast = 8,variate::item[0]--;
				if(each(ch,"tf"))break;
			}
		}
		init();
		tipid=rand()%variate::TIP_NUM;
		int fishtype = 0;
		if(rand()%100 < 10)fishtype = 2;
		else if(weather::getlight() == -1 && rand()%90 < 8)fishtype = 3;
		else if(variate::lv() >= 3 && rand()%82 < 3)fishtype = 4;
		else if(weather::getlight() == -1 && rand()%79 < 3)fishtype = 5;
		else if(rand()%76 < get_random::level_rand(3))fishtype = 1;
		
		fishing1(fishtype);
		sleep(0.5);
	}
	inline void shop(){
		clear();
		print("您现在拥有：");
		for(int i = 0; i < variate::ITEM_NUM; i++)
			print(to_string(i + 1) + ". " + variate::ITEM_NAME[i] + " x" + to_string(variate::item[i]));
		print("请选择（按q退出）");
		char type;
		while(true){
			type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r')continue;
			
			if(type == 'q')break;
			if(isdigit(type) && type - '0' <= variate::ITEM_NUM){
				int choose = type - '0';
				string s;
				getline(s);
				int num = getint(s);
				if(variate::item[choose] < num){print(variate::ITEM_NAME[choose] + "不足");break;}
				variate::money += variate::ITEM_SELL[choose] * num;
				variate::item[choose] -= num;
				printa("你一共卖出了" + s + "个" + variate::ITEM_NAME[choose] +"，获得了" + to_string(variate::ITEM_SELL[choose] * num) + "金币");
			}
		}	
	}
	void check_mxy(){
		print("欢迎查看美西螈的情况。");
		for(int i=0;i<variate::mxy.size();i++)
		{
			variate::mxy[i]+=max(time(0)-variate::mxytime[i],0l)/240;
			variate::xp+=max(time(0)-variate::mxytime[i],0l)/240;
			variate::mxytime[i]=time(0);
		}
		if(variate::mxy.size()==0)print("您还没有美西螈！");
		else for(int i=0;i<variate::mxy.size();i++)
			if(variate::mxy[i]>0)print(to_string(i+1)+"号美西螈已为您累计带来"+to_string(variate::mxy[i])+"点经验");
			else print(to_string(i+1)+"号美西螈还没有给您带来经验");
		printa("");
	}
	void sell_fish(){
		long long allgot = 0;
		for(int i=0;i<variate::FISH_NUM;i++)
			if(variate::FISH_TYPE[i] == 0)
				while(variate::fishNum[i] > 0){
					int got = get_random::level_rand(1);
					variate::money+=got;
					variate::fishNum[i]--;
					allgot+=got*variate::FISH_PRIZE[i];
					print("你卖出了一条"+variate::FISH_NAME[i]+"，获得了"+to_string(got*variate::FISH_PRIZE[i])+"金币",0);
					system("sleep 0.01");
				}
		printa("你总共获得了"+to_string(allgot)+"金币");
	}
	inline void kill_fish(){
		for(int i=0;i<variate::FISH_NUM;i++)
			if(variate::FISH_TYPE[i] == 1){
				variate::item[variate::FISH_TURN[i]]+=variate::fishNum[i];
				variate::fishNum[i] = 0;
			}
		print("宰杀完成。");
	}
	inline void unbroke(){
		print("您现在鱼竿的耐久为"+to_string(variate::naijiu)+'/'+to_string(variate::FULL_BROKEN_VALUE));
		print("请输入您要修复的耐久度：");
		int add = readint("",variate::FULL_BROKEN_VALUE - variate::naijiu);
		printa("您要修复"+to_string(add)+"点耐久，耗费"+to_string(add*variate::lv())+"元");
		if(add*variate::lv() > variate::money)print("钱不够");
		else{
			variate::naijiu += add;
			variate::money -= add*variate::lv();
			printa("已修复");
		}
	}
	void (*menu[6])() = {do_nothing_void, Fishing, sell_fish, kill_fish, check_mxy, unbroke};
	inline void fishing(){
		clear();
		print("1.开始钓鱼 2.卖出全部鱼 3.宰杀(发光)墨鱼 4.美西螈 5.修复 0.退出");
		print("您现在拥有：");
		for(int i = 0; i < variate::FISH_NUM; i++)
			print(to_string(i + 1) + ". " + variate::FISH_NAME[i] + " x" + to_string(variate::fishNum[i]));
		print("金币 x"+to_string(variate::money));
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}
			if(!each(type, "012345"))continue;
			clear();
			menu[type - '0']();
			break;
		}
	}
}
namespace shop{
	inline void check_fishing(){
		if(!variate::auto_fishing){
			return;
		}
		int now = time(0);
		variate::left += now - variate::ltime;
		variate::ltime = now;
		variate::money += variate::left / (variate::LEVEL[1][1][variate::level[1]] + 20) * variate::LEVEL[1][0][variate::level[1]];
		//variate::cnt += variate::left / (variate::level_number[0][1][variate::level[0]] + 20);
		variate::left %= (variate::LEVEL[0][1][variate::level[0]] + 20);
	}
	
	int zhuAdd[3][2] = {{1,2},{1,3},{2,4}};
	int Add[3][2] = {{1,2},{1,3},{1,3}};
	int outnew[3] = {2,3,5};
	
	inline void shop0(){
		clear();
		print("欢迎使用附魔台。");
		int add[3][variate::LEVEL_NUM]={};
		int zhu[3];

		for(int i = 0; i < 3; i++)zhu[i] = variate::get_level();
		for(int i = 0; i < 3; i++)add[i][zhu[i]] = get_random::random(zhuAdd[i][0],zhuAdd[i][1]);
		for(int i = 0; i < 3; i++)while(rand()%outnew[i] > 0)add[i][variate::get_level()] += get_random::random(Add[i][0],Add[i][1]);
		
		
		int cost[3]={5+variate::lv()*16,12+variate::lv()*24,20+variate::lv()*30};
		print("1." + variate::LEVEL_NAME[zhu[0]] + to_string(add[0][zhu[0]]) + "...?  ($"+to_string(cost[0])+")");
		print("2." + variate::LEVEL_NAME[zhu[1]] + to_string(add[1][zhu[1]]) + "...?  ($"+to_string(cost[1])+")");
		print("3." + variate::LEVEL_NAME[zhu[2]] + to_string(add[2][zhu[2]]) + "...?  ($"+to_string(cost[2])+")");

		print("只用输入编号, 输入 0 返回", 0.01);
		print("现在的附魔:");
		for(int i = 0; i < variate::LEVEL_NUM; i++)
			print("    " + variate::LEVEL_NAME[i] + " " + to_string(variate::level[i]));
		print("当前金币数量:"+to_string(variate::money));
		char type = 0;
		while(true){
			type = getch();
			if(!each(type, "1230"))continue;
			if(type == '0')break;
			int choose = type-'1';
			if(variate::money < cost[choose])
			{
				print("金钱不够");
				break;
			}
			variate::money-=cost[0];
			for(int i = 0; i < variate::LEVEL_NUM; i++)
				variate::level[i] = min(variate::level[i] + add[choose][i], variate::MAX_LEVEL);
			print("附魔成功");
			break;
		}
	}
	inline void key(){
		clear();
		int speed = variate::spead;
		variate::spead = 1000;
		print("欢迎使用\033[31m铁砧\033[0m");
		print("您现在拥有的\033[31m附魔书\033[0m为：");
		print("\033[31mke*.p*m\033[0m");
		print("请\033[31m输入您\033[0m要*上\033[31m的\033[0m*魔：");
		print("\033[31m1.*饵, 2.海**顾\033[0m, *.\033[31m力*, 4.**, 按*\033[0m退出");
		getch();
		print("\033[36m附魔成功\033[0m");
		system("sleep 0.5");
		clear();
		for(int i=0;i<=23;i++)
		{
			print(" ________________________");
			print("|    auto_fish system    |");
			print("|                        |");
			print("|      loading...        |");
			print("|                        |");
			string s="";
			for(int j=1;j<i;j++)s+="=";
			for(int j=i;j<=24;j++)s+='-';
			print("|"+s+"|");
			print("|________________________|");
			system("sleep 0.1");
			clear();
		}
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|     \033[31merror:time out\033[0m     |");
		print("|________________________|");
		system("sleep 0.06");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|========================|");
		print("|________________________|");
		system("sleep 0.12");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|      verfity...        |");
		print("|________________________|");
		system("sleep 0.3");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|        \033[36msuccess\033[0m         |");
		print("|________________________|");
		system("sleep 0.7");
		clear();
		variate::spead = speed;
		variate::statu = 2;
		variate::auto_fishing = true;
	}
	inline void shop2(){
		if(variate::statu == 1){key();return;}
		clear();
		while(true){
			clear();
			print("欢迎使用铁砧。");
			print("您现在拥有的附魔书为：");
			for(int i=0;i<variate::LEVEL_NUM;i++)
				for(int j=1;j<5;j++)
				{
					if(variate::book[i][j]==0)continue;
					print(variate::LEVEL_NAME[i]+to_string(j)+" x"+to_string(variate::book[i][j]));
				}
			print("请输入您要打上的附魔：");
			string s="";
			for(int i=0;i<variate::LEVEL_NUM;i++)s+=(to_string(i+1)+"."+variate::LEVEL_NAME[i]+" ");
			print(s+" 按0退出");
			char type;
			type=getch();
			if(type=='0')break;
			print("请输入您要打上的附魔级别：");
			char l;
			l=getch();
			if (type-'0'>variate::LEVEL_NUM||type<'1'||l>'4'||l<'1')
			{
				print("没有此类附魔书！");
				system("sleep 0.5");
				continue;
			}
			
			int nd[]={1,2,4,8,16};
			int need_xp=5+nd[l-'0'];
			int need_money=(l-'0')*10;
			print((string)"您要打上一个"+variate::LEVEL_NAME[type-'0'-1]+l+"的附魔书，消耗"+to_string(need_xp)+"经验，"+to_string(need_money)+"金币");
			print("确定要附魔吗？(t/f)");
			char res='p';
			while(res!='t'&&res!='s')res=getch();
			if(res=='t')
			{
				if(variate::book[type-'0'-1][l-'0']==0){print("没有该附魔书");system("sleep 0.5");continue;}
				if(variate::xp<need_xp){print("经验不足");system("sleep 0.5");continue;}
				if(variate::money<need_money){print("金币不足");system("sleep 0.5");continue;}
				variate::money-=need_money;
				variate::xp-=need_xp;
				variate::book[type-'1'][l-'0']--;
				variate::level[type-'1'] = max(variate::level[type-'1']+l-'0',variate::MAX_LEVEL);
				print("附魔成功");
				system("sleep 0.5");
			}
			else continue;
		}
	}
	inline void outlevel(){
		
		int nowon = -1;
		
		char c;
		while(true){
			clear();
			cout<<"请选择你要归0的附魔，a/d键移动，Enter确定"<<endl;
			if(nowon == -1)cout<<"\033[32m";
			cout<<"退出  "+color::NONE;
			for(int i=0;i<variate::LEVEL_NUM;i++)
			{
				if(variate::HIDE_LEVEL[i])continue;
				if(nowon == i)cout<<"\033[32m";
				cout<<variate::LEVEL_NAME[i]+"  "+color::NONE;
			}
			cout<<endl;
			c=getch();
			if(c==97)nowon = max(nowon-1,-1);
			if(c==100)nowon = min(nowon+1,variate::LEVEL_NUM-1);
			if(c==13&&nowon!=-1){
				printa("已去除"+variate::LEVEL_NAME[nowon]+"附魔，返还"+to_string(variate::level[nowon])+"经验");
				variate::xp+=variate::level[nowon];
				variate::level[nowon]=0;
				return;
			}
			if(c==13&&nowon==-1){
				return;
			}
			
		}
	}
	void (*menu[5])() = {do_nothing_void, shop0, shop2, outlevel, do_nothing_void};
	inline void shop(){
		clear();
		print("1.附魔台, 2.铁砧, 3.砂轮, 4.退出");
		char type;
		while(true){
			type = getch();
			if(!each(type, "1234"))continue;
			menu[type-'0']();
			break;
		}
	}
	inline void use(){
		clear();
		int speed = variate::spead;
		variate::spead = 1000;
		print("准备接收...");
		system("sleep 0.3");
		clear();
		int all=rand()%50+100;
		int now=0;
		while(now<all)
		{
			print((string)"接收进度："+to_string(now*100/all)+"%");
			string s=color::GREEN;
			for(int j=1;j<now*24/all;j++)s+="=";
			s+=color::NONE;
			for(int j=now*24/all;j<=24;j++)s+='-';
			print(s);
			int add=rand()%3+4;
			print((string)""+to_string(add)+"KB/s  "+to_string(now)+"/"+to_string(all)+"KB");
			now+=add;
			system("sleep 0.13");
			clear();
		}
		print("接收成功！");
		system("sleep 0.8");
		clear();
		print("解码中...");
		system("sleep 1");
		clear();
		if(variate::lv() >= 7 && variate::statu < 2)
		{
			print("解码成功");
			system("sleep 0.8");
			clear();
			print("key:");
			print("   password:23");
			print("   use:main");
			print("   from:auto_fish system");
			printa("");
			variate::statu = 1;
		}
		else {print("解码失败！");system("sleep 0.8");}
		variate::spead = speed;

	}
}
namespace checkpoint{
	bool auto_save_type = false;
	int timestamp = 0;
	string save_name;
	pair<string,string> getpair(string a)
	{
		string ans[2]={};
		int now=0;
		for(auto v:a)
			if(v==':'&&now==0)now++;
			else ans[now]+=v;
		return make_pair(ans[0],ans[1]);
	}
	inline void savechpnp(string name, bool b = true){
		system("mkdir cache >/dev/null 2>&1");
		{
			ofstream out("cache/name.txt");
			out << "name:"+name << endl;
			out << "version:24w04b" << endl;
		}
		{
			ofstream out("cache/user.txt");
			out << "money:"+to_string(variate::money) << endl;
			out << "xp:"+to_string(variate::xp) << endl;
			out << "statu:"+to_string(variate::statu) << endl;
			out << "time:"+to_string(variate::gametime) << endl;
			out << "lightlast:"+to_string(variate::lightlast) << endl;
			out << "weather:"+to_string(variate::weather) << endl;
			out << "gameday:"+to_string(variate::gameday) << endl;
			out << "naijiu:"+to_string(variate::naijiu) << endl;
		}
		{
			ofstream out("cache/info.txt");
			for(int i=0;i<variate::LEVEL_NUM;i++)out << "level"+to_string(i)+":"+to_string(variate::level[i]) << endl;
			for(int i=0;i<variate::ITEM_NUM;i++)out << "item"+to_string(i)+":"+to_string(variate::item[i]) << endl;
			for(int i=0;i<variate::FISH_NUM;i++)out << "cnt"+to_string(i)+":"+to_string(variate::fishNum[i]) << endl;
		}
		{
			ofstream out("cache/book.txt");
			for(int i=0;i<4;i++)
				for(int j=1;j<5;j++)
					out << "book["+to_string(i)+"]["+to_string(j)+"]:"+to_string(variate::book[i][j]) << std::endl;	
		}
		{
			ofstream out("cache/mxy.txt");
			out << "sum:" << to_string(variate::mxy.size()) << endl;
			for(int i=0;i<variate::mxy.size();i++)out << "mxy"+to_string(i)+':'+to_string(variate::mxy[i]) << endl;
		}
		system(("zip "+name+" cache/* >a").c_str());
		system(("mv "+name+".zip "+name+".cpt").c_str());
		system(("mv "+name+".cpt checkpoint/").c_str());
		
		if(b)cout << "存档成功。" << endl;
	}
	inline void readchpnp(string name){
		string gm3;
		system("rm -rf cache");
		system(("unzip checkpoint/"+name+".cpt >a 2>&1").c_str());
		std::map<string,string> m;
		{
			ifstream in("cache/name.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/user.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/info.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/book.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/mxy.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
				//cout<<gm3<<endl;
				//system("sleep 0.3");
			}
		}
		variate::username=m["name"];
		variate::money=getint(m["money"]);
		variate::xp=getint(m["xp"]);
		variate::statu=getint(m["statu"]);
		variate::gametime=getint(m["time"],variate::TIME_GAME_BEGIN);
		variate::lightlast=getint(m["lightlast"]);
		variate::weather=getint(m["weather"]);
		variate::naijiu=getint(m["naijiu"],variate::FULL_BROKEN_VALUE);
		variate::gameday=getint(m["gameday"],variate::DAY_GAME_BEGIN);
		int mxysum=getint(m["sum"]);
		
		for(int i=0;i<variate::LEVEL_NUM;i++)variate::level[i] = getint(m["level"+to_string(i)]);
		for(int i=0;i<variate::ITEM_NUM;i++)variate::item[i] = getint(m["item"+to_string(i)]);
		for(int i=0;i<variate::FISH_NUM;i++)variate::fishNum[i] = getint(m["cnt"+to_string(i)]);
		
		for(int i=0;i<4;i++)
			for(int j=1;j<5;j++)
				variate::book[i][j]=getint(m[(string)"book["+to_string(i)+"]["+to_string(j)+"]"]);
		
		variate::mxy.clear();
		variate::mxytime.clear();
		for(int i=0;i<mxysum;i++)
			variate::mxy.push_back(getint(m["mxy"+to_string(i)])),
			variate::mxytime.push_back(time(0));
	
	}
}/*
namespace tool{
	void ch(){
		clear();
		cout << "int money = " << variate::money << "; (金钱, 最大100000)" << endl << 
		"int level = " << variate::level << "; (上钩速度, 最小0, 最大25)" << endl << 
		"int get_level = " << variate::get_level << "; (钓鱼收益, 最小0, 最大29)" << endl << 
		"int bf = " << variate::bf << "; (大鱼概率, 最小20, 最大60)" << endl << 
		"double stime = " << variate::stime << "; (游戏倍速, 最大10, 最小1)" << endl <<
		"int xp = " << variate::xp << "; (经验, 最小0, 最大1000000)" << endl;
		print("1.修改money, 2.修改lever, 3.修改get_lever, 4.修改bf, 5.修改stime, 6.修改xp, 7.自动钓鱼机, 8.自动调整, 9.退出");
		while(true){
			char c = getch();
			if(c != '1' && c != '2' && c != '3' && c != '4' && c != '5' && c != '6' && c != '7' && c != '8' && c != '9'){
				continue;
			}
			if(c != '7' && c != '8' && c != '9'){
				cout << c << ".0";
				cout.flush();
			}
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 100000){
							s = 100000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::money = s;
			}else if(c == '2'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 25){
							s = 25;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::level = s;
				variate::lv = (variate::level + variate::get_level)/2;
			}else if(c == '3'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 29){
							s = 29;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::get_level = s;
				variate::lv = (variate::level + variate::get_level)/2;
			}else if(c == '4'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 60){
							s = 60;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::bf = s;
			}else if(c == '5'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 10){
							s = 10;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::stime = s;
			}else if(c == '6'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000000){
							s = 1000000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::xp = s;
			}else if(c == '7'){
				variate::auto_fishing = true;
			}else if(c == '8'){
				variate::money = 100000;
				variate::level = 25;
				variate::get_level = 29;
				variate::bf = 60;
				variate::stime = 10;
				variate::cnt = 100;
				variate::auto_fishing = true;
				variate::slip = 10;
			}
			break;
		}
	}
	void hack(){
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.修改状态, 3.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				ch();
				return;
			}else if(c == '3'){
				clear();
				return;
			}
		}
	}
	void lower_hack(){
		clear();
		cout << "  ______     ____      ____     _____" << endl << " |  ____|   / __ \\    / __ \\   |  __ \\" << endl << " | | ___   | |  | |  | |  | |  | |  | |" << endl << " | ||_  |  | |  | |  | |  | |  | |  | |" << endl << " | |__| |  | |__| |  | |__| |  | |__| | " << endl << " |______|   \\____/    \\____/   |_____/ " << endl << "                                        " << endl << "                                        " << endl;
		print("GOOD JOB");
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				clear();
				return;
			}
		}
	}
	void developer(){
		clear();
		string mi;
		print("欢迎来到开发者模式");
		cout << "请输入密码: ";
		cout.flush();
		getline(mi);
		//if(to_hash(mi) == 12386266893725306769ull){
		if(mi == "123456"){
			hack();
		}else{
			lower_hack();
		}
	}
}*/
namespace setting{
	string sysstr[]={" ________________________",
					 "|    auto_fish system    |",
					 "|                        |",
					 "|      loading...        |",
					 "|                        |",
					 "|                        |",
					 "|________________________|"};
	void showsys(int loading,string sleeptime){
		for(int i=0;i<5;i++)print(sysstr[i]);
		string s=color::GREEN;
		for(int j=1;j<loading;j++)s+="=";
		s+=color::NONE;
		for(int j=loading;j<=24;j++)s+='-';
		print("|"+s+"|");
		print(sysstr[6]);
		system(("sleep "+sleeptime).c_str());
		clear();
	}
	void showsysver(string sleeptime){
		for(int i=0;i<5;i++)print(sysstr[i]);
		print("|      verfity...        |");
		print(sysstr[6]);
	}
	void showsysfail(string sleeptime){
		for(int i=0;i<5;i++)print(sysstr[i]);
		print("|  \033[31merror:missing key.pem\033[0m |");
		print(sysstr[6]);
	}
	void setting(){
		print((string)"1.更改输出倍速, 2.自动钓鱼机开关(目前:"+(variate::auto_fishing?"开":"关")+") , 3.退出");
		print("当前输出倍速: " + to_string(variate::spead) + "(最大1000)");
		while(true){
			char c = getch();
			if(c == '1'){
				variate::spead = readint("新输出倍速：",1000);
				return;
			}else if(c == '2'){
				if(variate::auto_fishing==false)
				{
					print("未拥有");
					break;
				}
				variate::auto_fishing=!variate::auto_fishing;
				print(variate::auto_fishing?"已开启":"已关闭");
				break;
			}else if(c == '3'){
				return;
			}
		}
	}
	void load_sys(int status){
		int speed = variate::spead;
		variate::spead = 1000;
		for(int i=0;i<=24;i++)
		{
			showsys(i,"0.1");
			clear();
		}
		if(status == 0){
			showsysver("0.3");
			clear();
			showsysver("0.7");
			clear();
		}
		variate::spead = speed;
	}
	void sys(){
		load_sys(variate::statu);
		if(variate::statu == 0){
			return;
		}
		setting();
	}
}

namespace mobs{
	
}

int main(int argc,char ** argv){
    for(int i=0;i<argc;i++)
        if((string)argv[i] == "-test")
            variate::is_update = false,print(argv[i]);
	system("sleep 0.3");
    
	srand(time(0));
	system("stty raw");
	system("stty -echo");
	clear();
	variate::spead = 1000;
	for(int i=0;i<7;i++)print(setting::sysstr[i]);
	system("sleep 0.7");
	clear();
	string Name="";
	while(true)
	{
		clear();	
		print(" ________________________ ");
		print("|    auto_fish system    |");
		print("|                        |");
		print("| Please enter your name |");
		print("|                        |");
		string output=color::BLUE+Name+color::NONE;
		while(output.size()<22+string(color::BLUE+color::NONE).size())output+=' ';
		print("| "+output+" |");
		print("|________________________|");
		char c=getch();
		if((issymbol(c)||c<32)&&c!='\r'&&c!=127)continue;
		if(Name.size()<22&&c!='\r')Name+=c;
		if(c==127&&Name.size())Name=Name.substr(0,Name.size()-2);
		if(c=='\r'&&Name.size()){
			checkpoint::readchpnp(Name);
			break;
		}
	}
	variate::username=Name;
	
	clear();
	setting::load_sys(variate::statu);
	printa("欢迎来到自助钓鱼系统。");
	printa("你可以在这里钓鱼。");
	printa("升级装备可以让钓鱼效率更高。");
	variate::time0=time(0);
	if(variate::gametime < 0)variate::gametime = variate::TIME_GAME_BEGIN;
	typedef void (*MENU_FUNC)();
	map<char,MENU_FUNC> menu={
		{'1', fishing::fishing},
		{'2', shop::shop},
		{'3', shop::use},
		{'4', fishing::shop},
		{'\r', setting::sys},
		{91, do_nothing_void}
	};
	map<char,bool> is_menu{{'1',1},{'2',1},{'3',1},{'4',1},{'\r',1},{91,1}};
	while(true){
		clear();
		print((variate::statu>=2?"\033[36m":"\033[31m")+(string)"auto_fish system\033[0m",0);
		print((string)"1.开始钓鱼, 2.升级, 3.天线, 4.商店");
		if(variate::statu >= 2)print("Enter to \033[3mauto_fish system\033[0m",0.01);
		print("按 q 退出",0.01);
		print("只用输入编号，其他输入无效。", 0.01);
		while(true){
			system("stty raw");
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}

			if(type == 'q'){
				clear();
				system("stty cooked");
				system("stty echo");
				return 0;
			}
			if(!is_menu[type])continue;
			clear();
			menu[type]();
			break;
			 
		}
		if(variate::is_update)checkpoint::savechpnp(variate::username,false);
		shop::check_fishing();

		sleep(1);
	}
}

