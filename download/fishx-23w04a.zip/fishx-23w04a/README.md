## fishx使用方法
进入 `fishx` 所在目录，输入 `./fishx` 即可运行。
`./fishx` 后面可以有参数，可为：
- `-compile`：重新编译源码**但不运行**。
- `-test`：进入**测试模式**，不会对当前存档更改。
- `-admin`：开启**管理员模式**。
### 贡献者
- 代码编写者：`xhabc66`
- 原始代码贡献者：`lyuwenhan`
- 艺术贡献者：`锅里的果冻`
### 开源许可
本项目采用[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.txt)开源许可证，请不要以商业用途使用、修改、分发源代码！