#include<hashtable.h>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<ctime>
#include<map>
#include<algorithm>
using std::cin;
using std::cout;
using std::ostream;
using std::string;
using std::to_string;
using std::ifstream;
using std::ofstream;
using std::hash;
using std::setw;
using std::min;
using std::max;
using std::pair;
inline void clear(){
	system("clear");
}
struct endline{}endl;
inline ostream& operator<<(ostream& out, endline e){
	out.flush();
	out << '\r' << std::endl;
	return out;
}
inline char getch(){
	char c = getchar();
//	if(c == 3){
//		clear();
//		cout << "^C" << endl;
//		system("stty cooked");
//		system("stty echo");
//		exit(1);
//	}
//	if(c == 26){
//		clear();
//		cout << "^Z" << endl << "[1]+  Stopped                 fishing.run" << endl;
//		system("stty cooked");
//		system("stty echo");
//		exit(1);
//	}
	return c;
}
namespace variate{
	const string name[4]={"钓饵","海之眷顾","力量","时运"};
	const string tips[]={
		"要达到一定等级之后天线才会解码成功噢",
		"猜猜你下次看到这条tip是什么时候？",
		"为什么只有字符画渲染？\033[9m因为xhabc66不会（逃\033[0m"
	};
	const int tipsnum = 3;
	const int max_level = 30;
	const int max_level2 = 30;
	const int max_level3 = 10;
	const int max_level4 = 30;
	const int mintime[31] = { 50,  40, 40, 40, 30, 30, 30, 30, 20, 20, 10,  9,  7,  5,  4,  4,  3,  3,  3,  3, 3, 3, 2, 2, 2, 2, 1, 1, 1, 0, 0};
	const int maxtime[31] = {100, 100, 90, 80, 80, 70, 60, 50, 50, 40, 40, 40, 40, 40, 40, 35, 30, 25, 20, 10, 8, 7, 6, 5, 4, 3, 3, 2, 1, 1, 0};
	const int maxget[31] = {20, 20, 20, 30, 30, 40, 40, 40, 50, 50, 55, 60, 60, 60, 70, 70, 80, 80, 90, 100, 105, 110, 120, 130, 135, 140, 145, 150, 160, 180, 200};
	const int minget[31] = {10, 12, 15, 15, 20, 20, 25, 30, 35, 40, 40, 40, 45, 50, 60, 60, 60, 70, 80,  85,  85,  90,  95, 100, 100, 100, 100, 100, 100, 100, 200};
	const int slip_time[11] = {50, 40, 30, 20, 10, 5, 4, 3, 2, 1, 0};
	const int big_fish[31] = {20, 21, 22, 23, 24, 25, 26, 27, 28, 30, 32,
								  33, 34, 35, 36, 38, 40, 42, 44, 46, 48, 
								  50, 52, 54, 56, 58, 60, 62, 63, 64, 65};
	string to_stringf(double d){
		return to_string((int)d) + "." + to_string(((int)(d * 10)) % 10);
	}
	
	long long money = 0;
	int level = 0;
	int get_level = 0;
	int slip_level = 0;
	int bf_level = 0;
	int cnt = 0;
	int xp = 0;
	int statu = 0;
	int book[4][5];
	int light = 0;
	string username;
	int gametime = 480;
	int lightlast = 0;
	int weather = 0;
	
	int bf = 20;
	int slip = 50;
	int lv = 0;
	bool open_fishing = false;

	int stime = 1;
	long long ltime = 0, left = 0;
	bool auto_fishing = false;
	int get_fish = 0;
	int spead = 2;
	int time0;	
}
using variate::name;
bool issymbol(char type){
	string symbols = "({[<`~!@#$%^&*-_ +=|;:.?>]})\"'\\/";
	size_t found = symbols.find(type);
	if(found != string::npos){
		return true;
	}else{
		return false;
	}
}
inline int getint(string s){
	int a=0;
	for(auto v:s)
		if('0'<=v && v <='9')
			a=a*10+v-'0';
		else return 0;
	return a;
}
inline string getline(string &ans, bool b = false){
	ans = "";
	char a = 0;
	while((a = getch()) != '\r'){
		if(issymbol(a) || isdigit(a) || islower(a) || isupper(a)){
			ans += a;
			if(b){
				cout << a;
				cout.flush();
			}
		}
		if(a == 127 && ans.length()){
			ans.pop_back();
			if(b){
				cout << "\b \b";
				cout.flush();
			}
		}
	}
	cout << endl;
	return ans;
}
inline unsigned long long to_hash(string s){
	return static_cast<unsigned long long>(hash<string>{}(s));
}
namespace color{
	string NONE = "\033[m";
	string RED = "\033[0;32;31m";
	string LIGHT_RED = "\033[1;31m";
	string GREEN = "\033[0;32;32m";
	string LIGHT_GREEN = "\033[1;32m";
	string BLUE = "\033[0;32;34m";
	string LIGHT_BLUE = "\033[1;34m";
	string DARY_GRAY = "\033[1;30m";
	string CYAN = "\033[0;36m";
	string LIGHT_CYAN = "\033[1;36m";
	string PURPLE = "\033[0;35m";
	string LIGHT_PURPLE = "\033[1;35m";
	string BROWN = "\033[0;33m";
	string YELLOW = "\033[1;33m";
	string LIGHT_GRAY = "\033[0;37m";
	string WHITE = "\033[1;37m";
	string SHINE = "\033[5m";       //闪烁
	string DASH = "\033[9m";        //删除线
	string QUICKSHINE = "\033[6m";  //快闪
	string FANXIAN = "\033[7m";     //反显
	string XIAOYIN = "\033[8m";     //消隐, 消失隐藏
}
inline void sleep(double time){
	system(((string)"sleep " + to_string(time)).c_str());
}
inline void print(string s, double time = 0.02){
	if(variate::spead == 1000){
		cout << s << endl;
	}else{
		for(char i : s){
			sleep(time / variate::spead);
			cout << i;
			cout.flush();
		}
		cout << endl;
	}
}

inline void echo(string s)
{
	system(("echo \""+s+"\"").c_str());
	cout<<endl;
}

inline void printa(string s, double time = 0.02){
	print(s + "    (按enter继续)", time);
	while(getch() != '\r');
}
namespace get_random{
	inline int random(int l, int r){
		int len = r - l;
		int re = rand() * 1.0 / RAND_MAX * len + l;
		return re;
	}
	inline int level_rand(int l = variate::level){
		return random(variate::mintime[l], variate::maxtime[l]);
	}
	inline int gr(int l = variate::get_level){
		return random(variate::minget[l], variate::maxget[l]);
	}
	inline int gbr(int l = variate::get_level){
		return random(variate::minget[l] * 2, variate::maxget[l] * 2);
	}
	inline int get_rand(bool is_big){
		return (is_big ? gbr() : gr());
	}
	inline int getgiant_rand(){
		return random(9000, 10000);
	}
	inline bool get_book(){
		int l=0;
		if(rand()%10<5)l=1;
		else if(rand()%5<3)l=2;
		else if(rand()%4<3)l=3;
		else l=4;
		int type=rand()%4;
		if(type==0&&variate::level==variate::max_level)return false;
		if(type==1&&variate::get_level==variate::max_level2)return false;
		if(type==2&&variate::slip_level==variate::max_level3)return false;
		if(type==3&&variate::bf_level==variate::max_level4)return false;
		variate::book[type][l]++;
		printa((string)"你钓到了一本"+name[type]+to_string(l)+"的附魔书");
		return true;
	}
	inline bool light_fish(){
		if(rand()%90>=10)return 0;
		variate::light += 1;
		variate::xp += 1;
		printa("你钓到了一条发光墨鱼，获得了一个发光墨囊");
		return 1;
	}
	inline void get(bool is_big){
		if(rand()%100<10)if(get_book())return;
		variate::lightlast=max(variate::lightlast-1,0);
		if(variate::gametime<=360||1080<=variate::gametime)
			if(light_fish())
				return;
		int pri = get_rand(is_big);
		variate::money += pri;
		variate::xp += 1;
		bool getFish = (rand()%5==0?false:true);
		variate::get_fish += getFish;
		printa((string)"你钓到了一条" + (is_big ? "大" : "") + "鱼, 价值$" + to_string(pri) + ", "+(getFish?"并获得了一个鱼饵, ":"")+" 你现在有$" + to_string(variate::money));
	}
	inline void getgiant(){
		int pri = getgiant_rand();
		variate::money += pri;
		variate::xp += 3;
		printa((string)"你钓到了一条巨型鲨鱼, 价值$" + to_string(pri) + ", 你现在有$" + to_string(variate::money));
	}
}
class base64{
	private:
		int basedecode[128];
		char baseencode[65];
		char oth;
		bool use[7];
		int ans[7];
		int tot;
		char tb(int n){
			return baseencode[n & 0x3f];
		}
		void quan(int n, int b){
			if(n >= 6){
				tot++;
				return;
			}
			for(int i = 0; i <= 4; i++){
				if(use[i]){
					continue;
				}
				use[i] = true;
				ans[n] = i;
				quan(n + 1, b);
				use[i] = false;
				if(b == tot){
					return;
				}
			}
		}
		string get_password(string s){
			size_t ha = hash<string>{}(s);
			unsigned long long  num = static_cast<unsigned long long>(ha);
			char a[6] = "aA1";
			string list = "({[<`~!@#$%^&*-_+=|;:.?>]})";
			unsigned long long n1 = num / list.length();
			unsigned long long r1 = num % list.length();
			unsigned long long n2 = n1 / (list.length() - 1);
			unsigned long long r2 = n1 % (list.length() - 1);
			unsigned long long n3 = n2 / (list.length() - 2);
			unsigned long long r3 = n2 % (list.length() - 2);
			unsigned long long n4 = n3 / 120;
			unsigned long long r4 = n3 % 120;
			a[3] = list[r1];
			list.erase(r1, 1);
			a[4] = list[r2];
			list.erase(r2, 1);
			a[5] = list[r3];
			for(int i = 0; i <= 4; i++){
				use[i] = false;
				ans[i] = 0;
			}
			ans[6] = 5;
			quan(1, r4 + 1);
			string an;
			for(int i = 1; i <= 6; i++){
				an += a[ans[i]];
			}
			return an;
		}
		void set_base(string s){
			int i = 0;
			for(int i = 0; i < 64; i++){
				baseencode[i] = '\0';
			}
			for(int i = 0; i < 128; i++){
				basedecode[i] = '\0';
			}
			oth = s[5];
			for(int j = 0; j < 5; j++){
				if(isdigit(s[j])){
					for(int j = 0; j < 10; j++){
						basedecode[j + '0'] = i;
						baseencode[i++] = j + '0';
					}
				}else if(islower(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'a'] = i;
						baseencode[i++] = j + 'a';
					}
				}else if(isupper(s[j])){
					for(int j = 0; j < 26; j++){
						basedecode[j + 'A'] = i;
						baseencode[i++] = j + 'A';
					}
				}else{
					basedecode[s[j]] = i;
					baseencode[i++] = s[j];
				}
			}
		}
	public:
		base64(string s){
			set_base(s);
		}
		base64(string s, bool salt){
			if(salt){
				set_base(get_password(s + "add_salt"));
			}else{
				set_base(get_password(s + "no_salt"));
			}
		}
		string decode(string in){//jiema
			string ans;
			for(int i = 0; i < in.length(); i += 4){
				ans += (char)((unsigned char)basedecode[in[i]] << 2 | (unsigned char)basedecode[in[i + 1]] >> 4) & 0xff;
				if(in[i + 2] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 1]] << 4 | (unsigned char)basedecode[in[i + 2]] >> 2) & 0xff;
				}
				if(in[i + 3] != oth){
					ans += (char)((unsigned char)basedecode[in[i + 2]] << 6 | (unsigned char)basedecode[in[i + 3]]) & 0xff;
				}
			}
			return ans;
		}
		string encode(string in){//bianma
			string ans;
			for(int i = 0; i < in.length(); i += 3){
				ans += tb(((unsigned char)in[i] >> 2));
				ans += tb(((unsigned char)in[i] << 4) | (i + 1 >= in.length() ? 0 : ((unsigned char)in[i + 1] >> 4)));
				ans += (i + 1 >= in.length()) ? oth : tb(((unsigned char)in[i + 1] << 2) | (i + 2 >= in.length() ? 0 : ((unsigned char)in[i + 2] >> 6)));
				ans += (i + 2 >= in.length()) ? oth : tb(((unsigned char)in[i + 2]));
			}
			while(ans.length() % 4){
				ans += oth;
			}
			return ans;
		}
}b1("a[0]A`"), b2("(0aA);"), b3("|a0+A-");
namespace fishing{
	const string cloud[]={  "     _____    ",
							" ___/     \\__ ",
							"/   \\_    /  \\",
							"\\____________/"};
	const string sun[]={    "    ",
							" __ ",
							"/  \\",
							"\\__/"};
	const string moon[]={   " __  ",
							" | \\ ",
							" |  | ",
							" |_/ "};
	const string mb_pic[]={ "                                              ",
							"                                              ",
							"                                              ",
							"                                              ",
							"                         o                    ",
							"                        /|\\                   ",
							"                        /_\\___                ",
							"~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|~~",
							"                              |            |  ",
							"                              |      >O    |  ",
							"                              |____________|  "};
	string pic[]={			"                                              ",
							"                                              ",
							"                                              ",
							"                                              ",
							"                         o                    ",
							"                        /|\\                   ",
							"                        /_\\___                ",
							"~~~~~~~~~~~~~~~~~~~~~~~|      |~~~~~~~~~~~~|~~",
							"                              |            |  ",
							"                              |      >O    |  ",
							"                              |____________|  "};
	int tipid;
	inline void init(){for(int i=0;i<11;i++)pic[i]=mb_pic[i];}
	inline void printweather()
	{
		if(variate::weather == 1){
			cout<<color::NONE;
			for(int i=0;i<4;i++)cout<<cloud[i]<<endl;
		}else if(variate::gametime<=330 || 1110 <=variate::gametime){
			cout<<"\033[2m";
			for(int i=0;i<4;i++)cout<<moon[i]<<endl;
		}else if(360<=variate::gametime && variate::gametime<=1080){
			cout<<color::YELLOW;
			for(int i=0;i<4;i++)cout<<sun[i]<<endl;
		}else for(int i=0;i<4;i++)cout<<endl;
		cout<<color::NONE;
	}
	inline void showpic(double wait,bool reset = false)
	{
		variate::gametime=(variate::gametime+(time(0)-variate::time0)*2)%1440;
		variate::time0=time(0);
		clear();
		if(rand()%40 == 0)variate::weather = min(1,max(variate::weather+rand()%3-1,0));
		printweather();
		for(int i=0;i<11;i++){
			for(int j=0;j<44;j++)
			{
				cout<<color::NONE;
				if(pic[i][j]=='~')cout<<((variate::gametime>=360&&1080>=variate::gametime)?"\033[1;32;36m":"\033[1;32;34m");
				if(pic[i][j]=='j'&&variate::lightlast>0)cout<<color::YELLOW;
				cout<<pic[i][j];
			}
			cout<<endl;
		}
		cout<<"鱼："<<variate::cnt<<"  气温：22  天气："<<(variate::weather == 0?"晴":"多云")<<"  时间："<<variate::gametime/60<<':'<<variate::gametime%60<<endl;
		cout<<"tip:"<<variate::tips[tipid]<<endl;
		system(("sleep "+to_string(wait/variate::stime)).c_str());
		clear();
		if(reset)init();
	}

	inline void per_fishing(){
		pic[5][27]=pic[5][28]=pic[5][29]=pic[5][30]=pic[5][31]=pic[5][32]=pic[5][33]=pic[5][34]='-';
		showpic(0.5,true);
		pic[5][26]='V';pic[4][27]=pic[3][28]=pic[2][29]=pic[1][30]=pic[0][31]='/';
		showpic(0.5,true);
		pic[5][26]='|';pic[4][26]=pic[3][26]=pic[2][26]=pic[1][26]=pic[0][26]='|';
		showpic(0.5,true);
		pic[5][24]='|';pic[4][24]=pic[3][24]=pic[2][24]=pic[1][24]=pic[0][24]='|';
		showpic(0.5,true);
		pic[5][24]='V';pic[4][23]=pic[3][22]=pic[2][21]=pic[1][20]=pic[0][19]='\\';
		showpic(0.5);
		for(int i=1;i<8;i++)
		{
			pic[i][18]='j';
			pic[i-1][18]='|';
			showpic(0.5);
		}
	}

	inline void wait_fish(){
		int wait_time=get_random::level_rand();
		if(variate::gametime <= 360 || 1080 <= variate::gametime)
		{
			wait_time*=((rand()%20+140)/100.0);
			if(variate::lightlast)wait_time*=((rand()%10+45)/100.0);
		}
		for(int i=0;i<2*wait_time;i++)showpic(0.5);
	}

	inline void fish_come(){
		pic[7][0]='O';
		showpic(0.5);
		for(int i=1;i<=18;i++)
		{
			pic[7][i]='O';
			pic[7][i-1]='>';
			if(i>1)pic[7][i-2]='~';
			showpic(0.5);
		}
		pic[7][17]='~';
		pic[6][18]='O';
		pic[7][18]='^';
		showpic(0.5);
	}

	inline void fish_up()
	{
		pic[5][18]='O';
		pic[6][18]='^';
		pic[7][18]='~';
		showpic(0.5);
		for(int i=4;i>=0;i--)
		{
			pic[i][18]='O';
			pic[i+1][18]='^';
			pic[i+2][18]=' ';
			showpic(0.5);
		}
		pic[0][18]=pic[1][18]=' ';
		pic[0][18]='O';pic[0][17]='>';
		showpic(0.5);
		pic[0][18]=' ';pic[0][17]=' ';
		pic[4][23]=pic[3][22]=pic[2][21]=pic[1][20]=pic[0][19]=' ';
		pic[5][24]='|';pic[4][24]=pic[3][24]=pic[2][24]=pic[1][24]=pic[0][24]='|';
		pic[0][24]='O';pic[0][23]='>';
		showpic(0.5,true);
		pic[5][26]='|';pic[4][26]=pic[3][26]=pic[2][26]=pic[1][26]=pic[0][26]='|';
		pic[0][26]='O';pic[0][25]='>';
		showpic(0.5,true);
		pic[5][26]='V';pic[4][27]=pic[3][28]=pic[2][29]=pic[1][30]=pic[0][31]='/';
		pic[0][31]='O';pic[0][30]='>';
		showpic(0.5,true);
		pic[5][27]=pic[5][28]=pic[5][29]=pic[5][30]=pic[5][31]=pic[5][32]=pic[5][33]=pic[5][34]='-';
		pic[5][35]='O';pic[4][35]='V';
		showpic(0.5);
		pic[6][35]='O';pic[5][35]='V';pic[4][35]=' ';
		showpic(0.5);
		pic[7][35]='O';pic[6][35]='V';pic[5][35]=' ';pic[7][34]='\\';pic[7][36]='/';
		showpic(0.5);
		pic[8][35]='O';pic[7][35]='V';pic[6][35]=' ';
		showpic(0.5);
		pic[9][35]='O';pic[8][35]='V';pic[7][34]=pic[7][35]=pic[7][36]='~';
		showpic(0.5);
		pic[9][36]='O';pic[9][35]='>';pic[8][35]=' ';
		showpic(0.5);
		pic[9][37]='O';pic[9][36]='>';pic[9][35]=' ';
		showpic(0.5);
		pic[9][38]='O';pic[9][37]='>';pic[9][36]=' ';
		showpic(0.5);
	}

	inline void fish_run(){
		pic[5][18]='O';
		pic[6][18]='^';
		pic[7][18]='~';
		for(int i=4;i>=0;i--)
		{
			pic[i][18]='O';
			pic[i+1][18]='^';
			pic[i+2][18]=' ';
			showpic(0.5);
		}
		for(int i=1;i<7;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			if(i>1)pic[i-2][18]=' ';
			showpic(0.5);
		}
		pic[7][17]='\\';pic[7][19]='/';
		for(int i=7;i<9;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			pic[i-2][18]=' ';
			showpic(0.5);
		}
		pic[7][17]=pic[7][18]=pic[7][19]='~';
		for(int i=9;i<11;i++)
		{
			pic[i][18]='O';
			pic[i-1][18]='V';
			if(i>9)pic[i-2][18]=' ';
			showpic(0.5);
		}
		pic[10][18]='V';pic[9][18]=' ';
		showpic(0.5);
	}



	inline void fishing0(bool is_big){
		per_fishing();
		wait_fish();
		fish_come();
		fish_up();
		variate::cnt = 1;
		sleep(0.5 * (is_big + 1) / variate::stime);
		clear();
		get_random::get(is_big);
	}
	inline void fishing1(bool is_big){
		per_fishing();
		wait_fish();
		fish_come();
		fish_up();
		variate::cnt++;
		get_random::get(is_big);
	}
	inline void fishing1die(bool is_big){
		per_fishing();
		wait_fish();
		fish_come();
		fish_run();
	}
	inline void fishing(){
		init();
		tipid=rand()%variate::tipsnum;
		bool b = (get_random::random(1, 100) <= variate::bf);
		if(variate::cnt){
			bool die = (get_random::random(1, 100) <= variate::slip);
			if(die){
				fishing1die(b);
			}else{
				fishing1(b);
			}
		}else{
			fishing0(b);
		}
	}
}
namespace shop{
	inline void check_fishing(){
		if(!variate::open_fishing||!variate::auto_fishing){
			return;
		}
		int now = time(0);
		variate::left += now - variate::ltime;
		variate::ltime = now;
		variate::money += variate::left / (variate::mintime[variate::level] + 20) * variate::maxget[variate::get_level];
		variate::cnt += variate::left / (variate::mintime[variate::level] + 20);
		variate::left %= (variate::mintime[variate::level] + 20);
	}
	
	inline void shop0(){
		clear();
		print("欢迎使用附魔台。");
		int add[3][4];
		int zhu[3];
		for(int i=0;i<3;i++)zhu[i]=rand()%4;
		for(int i=0;i<4;i++)
			if(i==zhu[0])add[0][i]=rand()%2+1;
			else add[0][i]=(rand()%8?1:0);
		for(int i=0;i<4;i++)
			if(i==zhu[1])add[1][i]=rand()%3+1;
			else add[1][i]=(rand()%4?rand()%3+1:0);
		for(int i=0;i<4;i++)
			if(i==zhu[2])add[2][i]=rand()%3+2;
			else add[2][i]=(rand()%2?rand()%3+1:0);
		
		int cost[3]={8+variate::lv*20,16+variate::lv*30,24+variate::lv*45};
		print("1." + name[zhu[0]] + to_string(add[0][zhu[0]]) + "...?  ($"+to_string(cost[0])+")");
		print("2." + name[zhu[1]] + to_string(add[1][zhu[1]]) + "...?  ($"+to_string(cost[1])+")");
		print("3." + name[zhu[2]] + to_string(add[2][zhu[2]]) + "...?  ($"+to_string(cost[2])+")");

		//print("1.升级上钩速度, 2.升级钓鱼收益, 3.脱钩概率, 4.返回。");
		print("只用输入编号, 输入 4 返回", 0.01);
		print("现在的附魔:");
		print("    钓饵 "+to_string(variate::level));
		print("    海之眷顾 "+to_string(variate::get_level));
		print("    力量 "+to_string(variate::slip_level));
		print("    时运 "+to_string(variate::bf_level));
		print("当前金币数量:"+to_string(variate::money));
		char type = 0;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::money < cost[0])
				{
					print("金钱不够");
					break;
				}
				else{
					variate::money-=cost[0];
					variate::level=min(variate::level+add[0][0],variate::max_level);
					variate::get_level=min(variate::get_level+add[0][1],variate::max_level2);
					variate::slip_level=min(variate::slip_level+add[0][2],variate::max_level3);
					variate::bf_level=min(variate::bf_level+add[0][3],variate::max_level4);
					variate::slip = variate::slip_time[variate::slip_level];
					variate::bf = variate::big_fish[variate::bf_level];
					variate::lv=(variate::level+variate::get_level)/2;
					print("附魔成功");
					break;
				}
			}else if(type == '2'){
				if(variate::money < cost[1])
				{
					print("金钱不够");
					break;
				}
				else{
					variate::money-=cost[1];
					variate::level=min(variate::level+add[1][0],variate::max_level);
					variate::get_level=min(variate::get_level+add[1][1],variate::max_level2);
					variate::slip_level=min(variate::slip_level+add[1][2],variate::max_level3);
					variate::bf_level=min(variate::bf_level+add[1][3],variate::max_level4);
					variate::slip = variate::slip_time[variate::slip_level];
					variate::bf = variate::big_fish[variate::bf_level];
					variate::lv=(variate::level+variate::get_level)/2;
					print("附魔成功");
					break;
				}
			}else if(type == '3'){
				if(variate::money < cost[2])
				{
					print("金钱不够");
					break;
				}
				else{
					variate::money-=cost[2];
					variate::level=min(variate::level+add[2][0],variate::max_level);
					variate::get_level=min(variate::get_level+add[2][1],variate::max_level2);
					variate::slip_level=min(variate::slip_level+add[2][2],variate::max_level3);
					variate::bf_level=min(variate::bf_level+add[2][3],variate::max_level4);
					variate::slip = variate::slip_time[variate::slip_level];
					variate::bf = variate::big_fish[variate::bf_level];
					variate::lv=(variate::level+variate::get_level)/2;
					print("附魔成功");
					break;
				}
			}else if(type == '4'){
				break;
			}
		}
	}
	inline void shop1(){
		clear();
		printa("这里是超级商店, 可以买一些特殊的商品。");
		clear();
		print("1.游戏倍速, 2.购买自动钓鱼机, 3.返回。");
		print("只用输入编号", 0.01);
		print("游戏倍速: ");
		if(variate::stime == 0.1){
			print("    等级已满。");
		}else{
			print("    当前倍速: " + to_string(variate::stime) + ", 升级后游戏倍速: " + to_string(variate::stime + 1));
			print("    升级花费: $1000, 当前金币数量: $" + to_string(variate::money));
		}
		
		print("自动钓鱼机: ");
		if(variate::auto_fishing){
			print("    已有");
		}else{
			print("    升级花费: $2000, 当前金币数量: $" + to_string(variate::money));
		}
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				if(variate::stime >= 10){
					print("等级已满。");
					break;
				}else if(variate::money < 1000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 1000;
					variate::stime++;
					print("购买成功");
					break;
				}
			}else if(type == '2'){
				if(variate::open_fishing){
					print("已有。");
					break;
				}else if(variate::money < 2000){
					print("金钱不够");
					break;
				}else{
					variate::money -= 2000;
					variate::open_fishing = true;
					variate::ltime = time(0);
					print("购买成功");
					break;
				}
				break;
			}else if(type == '3'){
				break;
			}
		}
	}
	inline void key(){
		clear();
		int speed = variate::spead;
		variate::spead = 1000;
		print("欢迎使用\033[31m铁砧\033[0m");
		print("您现在拥有的\033[31m附魔书\033[0m为：");
		print("\033[31mke*.p*m\033[0m");
		print("请\033[31m输入您\033[0m要*上\033[31m的\033[0m*魔：");
		print("\033[31m1.*饵, 2.海**顾\033[0m, *.\033[31m力*, 4.**, 按*\033[0m退出");
		getch();
		print("\033[36m附魔成功\033[0m");
		system("sleep 0.5");
		clear();
		for(int i=0;i<=23;i++)
		{
			print(" ________________________");
			print("|    auto_fish system    |");
			print("|                        |");
			print("|      loading...        |");
			print("|                        |");
			string s="";
			for(int j=1;j<i;j++)s+="=";
			for(int j=i;j<=24;j++)s+='-';
			print("|"+s+"|");
			print("|________________________|");
			system("sleep 0.1");
			clear();
		}
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|     \033[31merror:time out\033[0m     |");
		print("|________________________|");
		system("sleep 0.06");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|========================|");
		print("|________________________|");
		system("sleep 0.12");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|      verfity...        |");
		print("|________________________|");
		system("sleep 0.3");
		clear();
		print(" ________________________");
		print("|    auto_fish system    |");
		print("|                        |");
		print("|      loading...        |");
		print("|                        |");
		print("|        \033[36msuccess\033[0m         |");
		print("|________________________|");
		system("sleep 0.7");
		clear();
		variate::spead = speed;
		variate::statu = 2;
		variate::open_fishing = true;
	}
	inline void shop2(){
		if(variate::statu == 1){key();return;}
		clear();
		while(true){
			clear();
			print("欢迎使用铁砧。");
			print("您现在拥有的附魔书为：");
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
				{
					if(variate::book[i][j]==0)continue;
					print(name[i]+to_string(j)+" x"+to_string(variate::book[i][j]));
				}
			print("请输入您要打上的附魔：");
			print("1.钓饵, 2.海之眷顾, 3.力量, 4.时运, 按0退出");
			char type;
			type=getch();
			if(type=='0')break;
			print("请输入您要打上的附魔级别：");
			char l;
			l=getch();
			if (type>'4'||type<'1'||l>'4'||l<'1')
			{
				print("没有此类附魔书！");
				system("sleep 0.5");
				continue;
			}
			
			int nd[]={1,2,4,8,16};
			int need_xp=5+nd[l-'0'];
			int need_money=(l-'0')*10;
			print((string)"您要打上一个"+name[type-'0'-1]+l+"的附魔书，消耗"+to_string(need_xp)+"经验，"+to_string(need_money)+"金币");
			print("确定要附魔吗？(t/f)");
			char res='p';
			while(res!='t'&&res!='s')res=getch();
			if(res=='t')
			{
				if(variate::book[type-'0'-1][l-'0']==0){print("没有该附魔书");system("sleep 0.5");continue;}
				if(variate::xp<need_xp){print("经验不足");system("sleep 0.5");continue;}
				if(variate::money<need_money){print("金币不足");system("sleep 0.5");continue;}
				variate::money-=need_money;
				variate::xp-=need_xp;
				variate::book[type-'0'-1][l-'0']--;
				if(type=='1')variate::level=min(variate::level+l-'0',variate::max_level);
				if(type=='2')variate::get_level=min(variate::get_level+l-'0',variate::max_level2);
				if(type=='3')variate::slip_level=min(variate::slip_level+l-'0',variate::max_level3);
				if(type=='4')variate::bf_level=min(variate::bf_level+l-'0',variate::max_level4);
				variate::slip = variate::slip_time[variate::slip_level];
				variate::bf = variate::big_fish[variate::bf_level];
				variate::lv=(variate::level+variate::get_level)/2;	
				print("附魔成功");
				system("sleep 0.5");
			}
			else continue;
		}
	}
	inline void shop(){
		clear();
		print("1.附魔台, 2.铁砧, 3.退出。");
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				shop0();
				break;
			}else if(type == '2'){
				shop1();
				break;
			}else if(type == '3'){
				break;
			}
		}
	}
	inline void use(){
		clear();
		print((string)"1.天线, 2.发光墨囊("+(variate::lightlast?"使用中":"剩余："+to_string(variate::light))+"), 3.退出");
		char type;
		while(true){
			type = getch();
			if(type == '1'){
				int speed = variate::spead;
				variate::spead = 1000;
				print("准备接收...");
				system("sleep 0.3");
				clear();
				int all=rand()%50+100;
				int now=0;
				while(now<all)
				{
					print((string)"接收进度："+to_string(now*100/all)+"%");
					string s=color::GREEN;
					for(int j=1;j<now*24/all;j++)s+="=";
					s+=color::NONE;
					for(int j=now*24/all;j<=24;j++)s+='-';
					print(s);
					int add=rand()%3+4;
					print((string)""+to_string(add)+"KB/s  "+to_string(now)+"/"+to_string(all)+"KB");
					now+=add;
					system("sleep 0.13");
					clear();
				}
				print("接收成功！");
				system("sleep 0.8");
				clear();
				print("解码中...");
				system("sleep 1");
				clear();
				if(variate::lv >= 20)
				{
					print("解码成功");
					system("sleep 0.8");
					clear();
					print("key:");
					print("   password:23");
					print("   use:main");
					print("   from:auto_fish system");
					printa("");
					variate::statu = 1;
				}
				else {print("解码失败！");system("sleep 0.8");}
				variate::spead = speed;
				break;
			}else if(type == '2'){
				if(variate::lightlast)print("使用中");
				else{
					if(variate::light == 0)print("没有发光墨囊");
					else{
						variate::light--;
						variate::lightlast = 8;
						print("已使用");
					}
				}
				break;
			}else if(type == '3'){
				break;
			}
		}
	}
}
namespace checkpoint{
	bool auto_save_type = false;
	int timestamp = 0;
	string save_name;
	pair<string,string> getpair(string a)
	{
		string ans[2]={};
		int now=0;
		for(auto v:a)
			if(v==':'&&now==0)now++;
			else ans[now]+=v;
		return make_pair(ans[0],ans[1]);
	}
	inline string de(){
		string s;
		s += "coin:";
		s += to_string(variate::money);
		s += "lv:";
		s += to_string(variate::level);
		s += "lv2:";
		s += to_string(variate::get_level);
		s += "c:";
		s += to_string(variate::cnt);
		s += "bf:";
		s += to_string(variate::bf);
		s += "st:";
		s += to_string(variate::stime);
		s += "af:";
		s += (variate::auto_fishing ? "t" : "f");
		s += "slip:";
		s += to_string(variate::slip);
		s += "sliplv:";
		s += to_string(variate::slip_level);
		s += "bflv:";
		s += to_string(variate::bf_level);
		s += "xp:";
		s += to_string(variate::xp);
		s += "book:";
		
		for(int i=0;i<4;i++)for(int j=0;j<4;j++)s+=to_string(variate::book[i][j])+':';
		return s;
	}
	inline string encode(){
		string s = de();
		string gm1 = b1.encode(s);
		string gm2 = b2.encode(gm1);
		string gm3 = b3.encode(gm2);
		return gm3;
	}
	inline void decode(string gm3){
		string gm2, gm1, s, s_2, gm1_2, gm2_2, gm3_2;
		long long coin;
		int lv=0, lv2=0, c=0, bf=20, st=1, sl=50, slv=0, bflv=0, xp=0;
		int bk[4][4]={};
		char autofishing='f';
		if(b3.encode(gm2 = b3.decode(gm3)) != gm3){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询1" << endl;
			return;
		}
		if(b2.encode(gm1 = b2.decode(gm2)) != gm2){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		if(b1.encode(s = b1.decode(gm1)) != gm1){
			cout << "存档损坏, 请换个文件再试试。具体文件可以去checkpoint/name.txt中查询2" << endl;
			return;
		}
		//print(s);//system("sleep 11");
		sscanf(s.c_str(), "coin:%lldlv:%dlv2:%dc:%dbf:%dst:%daf:%cslip:%dsliplv:%dbflv:%dxp:%dbook:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:%d:", 
							&coin, &lv, &lv2, &c, &bf, &st, &autofishing, &sl, &slv, &bflv, &xp,
							&bk[0][0],&bk[0][1],&bk[0][2],&bk[0][3],&bk[1][0],&bk[1][1],&bk[1][2],&bk[1][3],
							&bk[2][0],&bk[2][1],&bk[2][2],&bk[2][3],&bk[3][0],&bk[3][1],&bk[3][2],&bk[3][3]);
		//print(s);
		//system("sleep 13");
		variate::money = coin;
		variate::level = lv;
		variate::get_level = lv2;
		variate::cnt = c;
		variate::bf = bf;
		variate::stime = st;
		variate::auto_fishing = (autofishing == 't');
		variate::slip = sl;
		variate::slip_level = slv;
		variate::bf_level = bflv;
		variate::xp = xp;
		variate::lv=(variate::level+variate::get_level)/2;
		for(int i=0;i<4;i++)for(int j=0;j<4;j++)variate::book[i][j+1]=bk[i][j];
		if(variate::auto_fishing){
			variate::ltime = time(0);
		}
		cout << "读取成功。" << endl;
	}
	inline void savechpnp(string name, bool b = true){
		system("mkdir cache >a 2>&1");
		{
			ofstream out("cache/name.txt");
			out << "name:"+name << endl;
			out << "version:24w02a" << endl;
		}
		{
			ofstream out("cache/user.txt");
			out << "money:"+to_string(variate::money) << endl;
			out << "lv:"+to_string(variate::level) << endl;
			out << "getlv:"+to_string(variate::get_level) << endl;
			out << "sliplv:"+to_string(variate::slip_level) << endl;
			out << "bflv:"+to_string(variate::bf_level) << endl;
			out << "cnt:"+to_string(variate::cnt) <<endl;
			out << "xp:"+to_string(variate::xp) << endl;
			out << "statu:"+to_string(variate::statu) << endl;
			out << "time:"+to_string(variate::gametime) << endl;
			out << "light:"+to_string(variate::light) << endl;
			out << "lightlast:"+to_string(variate::lightlast) << endl;
			out << "weather:"+to_string(variate::weather) << endl;
			
		}
		{
			ofstream out("cache/book.txt");
			for(int i=0;i<4;i++)
				for(int j=1;j<5;j++)
					out << "book["+to_string(i)+"]["+to_string(j)+"]:"+to_string(variate::book[i][j]) << std::endl;	
		}
		system(("zip "+name+" cache/* >a").c_str());
		system(("mv "+name+".zip "+name+".cpt").c_str());
		system(("mv "+name+".cpt checkpoint/").c_str());
		
		if(b)cout << "存档成功。" << endl;
	}
	inline void savechp(string name){
		string ba, ba2;
		cout << "输入你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba);
		if(ba == "exit"){
			return;
		}
		cout << "确认你的保存密码, 输入\"exit\"即可退出: ";
		cout.flush();
		getline(ba2);
		if(ba2 == "exit"){
			return;
		}
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		base64 base(ba, false);
		ofstream out("checkpoint/" + name + ".checkpoint");
		string gm4 = base.encode(encode());
		out << gm4 << endl;
		system(("echo \"" + name + "\" >> checkpoint/name.txt").c_str());
		system("sort -u -o checkpoint/name.txt checkpoint/name.txt");
		cout << "存档成功。" << endl;
	}
	inline void readchpnp(string name){
		string gm3;
		system("rm -rf cache");
		system(("unzip checkpoint/"+name+".cpt >a 2>&1").c_str());
		std::map<string,string> m;
		{
			ifstream in("cache/name.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/user.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		{
			ifstream in("cache/book.txt");
			while(in>>gm3){
				pair<string,string> p=getpair(gm3);
				m[p.first]=p.second;
			}
		}
		variate::username=m["name"];
		variate::money=getint(m["money"]);
		variate::level=getint(m["lv"]);
		variate::get_level=getint(m["getlv"]);
		variate::slip_level=getint(m["sliplv"]);
		variate::bf_level=getint(m["bflv"]);
		variate::cnt=getint(m["cnt"]);
		variate::xp=getint(m["xp"]);
		variate::statu=getint(m["statu"]);
		variate::gametime=getint(m["time"]);
		variate::light=getint(m["light"]);
		variate::lightlast=getint(m["lightlast"]);
		variate::weather=getint(m["weather"]);
		
		for(int i=0;i<4;i++)
			for(int j=1;j<5;j++)
				variate::book[i][j]=getint(m[(string)"book["+to_string(i)+"]["+to_string(j)+"]"]);
	
		variate::lv=(variate::level+variate::get_level)/2;
		variate::slip=variate::slip_time[variate::slip_level];
		variate::bf=variate::big_fish[variate::bf_level];
		variate::open_fishing=(variate::statu>=2);
	}
	inline void readchp(string name){
		string gm4;
		ifstream in("checkpoint/" + name + ".checkpoint");
		if(!in.good()){
			cout << "文件名错误, 具体文件可以去checkpoint/name.txt中查询" << endl;
			return;
		}
		in >> gm4;
		string ba, ba2;
		cout << "输入你的读取密码: ";
		cout.flush();
		getline(ba);
		cout << "确认你的读取密码: ";
		cout.flush();
		getline(ba2);
		if(ba != ba2){
			cout << "两次密码不一样" << endl;
			return;
		}
		clear();
		base64 base(ba, false);
		decode(base.decode(gm4));
	}
	inline void save(){
		print("1.无密码保存 2.带密码保存 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				
				savechpnp(name);
				break;
			}else if(type == '2'){
				savechp(name);
				break;
			}
		}
	}
	inline void read(){
		print("1.无密码读取 2.带密码读取 3.退出");
		cout << endl;
		while(true){
			char type = getch();
			if(type == '3'){
				break;
			}
			if(type != '1' && type != '2'){
				continue;
			}
			clear();
			string name;
			while(true){
				cout << "加载文件(只能有数字和大小写字母和下划线。), 输入\"exit\"即可退出: ";
				cout.flush();
				getline(name, true);
				if(name == "exit"){
					return;
				}
				bool b = true;
				for(char i : name){
					if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
						b = false;
						break;
					}
				}
				if(b){
					break;
				}
				cout << "名称错误" << endl;
				return;
			}
			if(type == '1'){
				readchpnp(name);
				break;
			}else if(type == '2'){
				readchp(name);
				break;
			}
		}
	}
	inline void check(){
		printa(de());
	}
	inline void auto_save(){return;
		if(auto_save_type){
			savechpnp(save_name + "_savetime_" + to_string(timestamp++), false);
		}
	}
	inline void set_auto_save(){
		string name;
		cout << "保存文件名(只能有数字和大小写字母和下划线, 重复名称将覆盖。), 最后文件将保存为\"名称_savetime_时间戳\", 例如\"c_savetime_3\", 输入\"exit\"即可退出: ";
		cout.flush();
		getline(name, true);
		if(name == "exit"){
			return;
		}
		bool b = true;
		for(char i : name){
			if(!(isdigit(i) || islower(i) || isupper(i) || (i == '_'))){
				b = false;
				break;
			}
		}
		if(b){
			clear();
			auto_save_type = true;
			save_name = name;
			timestamp = 1;
			cout << "设置成功" << endl;
		}else{
			cout << "名称错误" << endl;
		}
	}
}
namespace tool{
	void ch(){
		clear();
		cout << "int money = " << variate::money << "; (金钱, 最大100000)" << endl << 
		"int level = " << variate::level << "; (上钩速度, 最小0, 最大25)" << endl << 
		"int get_level = " << variate::get_level << "; (钓鱼收益, 最小0, 最大29)" << endl << 
		"int bf = " << variate::bf << "; (大鱼概率, 最小20, 最大60)" << endl << 
		"double stime = " << variate::stime << "; (游戏倍速, 最大10, 最小1)" << endl <<
		"int xp = " << variate::xp << "; (经验, 最小0, 最大1000000)" << endl;
		print("1.修改money, 2.修改lever, 3.修改get_lever, 4.修改bf, 5.修改stime, 6.修改xp, 7.自动钓鱼机, 8.自动调整, 9.退出");
		while(true){
			char c = getch();
			if(c != '1' && c != '2' && c != '3' && c != '4' && c != '5' && c != '6' && c != '7' && c != '8' && c != '9'){
				continue;
			}
			if(c != '7' && c != '8' && c != '9'){
				cout << c << ".0";
				cout.flush();
			}
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 100000){
							s = 100000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::money = s;
			}else if(c == '2'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 25){
							s = 25;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::level = s;
				variate::lv = (variate::level + variate::get_level)/2;
			}else if(c == '3'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 29){
							s = 29;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::get_level = s;
				variate::lv = (variate::level + variate::get_level)/2;
			}else if(c == '4'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 60){
							s = 60;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::bf = s;
			}else if(c == '5'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 10){
							s = 10;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::stime = s;
			}else if(c == '6'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000000){
							s = 1000000;
						}
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << c << '.' << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::xp = s;
			}else if(c == '7'){
				variate::auto_fishing = true;
			}else if(c == '8'){
				variate::money = 100000;
				variate::level = 25;
				variate::get_level = 29;
				variate::bf = 60;
				variate::stime = 10;
				variate::cnt = 100;
				variate::auto_fishing = true;
				variate::slip = 10;
			}
			break;
		}
	}
	void hack(){
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.修改状态, 3.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				ch();
				return;
			}else if(c == '3'){
				clear();
				return;
			}
		}
	}
	void lower_hack(){
		clear();
		cout << "  ______     ____      ____     _____" << endl << " |  ____|   / __ \\    / __ \\   |  __ \\" << endl << " | | ___   | |  | |  | |  | |  | |  | |" << endl << " | ||_  |  | |  | |  | |  | |  | |  | |" << endl << " | |__| |  | |__| |  | |__| |  | |__| | " << endl << " |______|   \\____/    \\____/   |_____/ " << endl << "                                        " << endl << "                                        " << endl;
		print("GOOD JOB");
		clear();
		print("欢迎来到开发者模式");
		print("1.查看当前状态, 2.退出");
		while(true){
			char c = getch();
			if(c == '1'){
				clear();
				cout << checkpoint::de() << endl;
				sleep(5);
				return;
			}else if(c == '2'){
				clear();
				return;
			}
		}
	}
	void developer(){
		clear();
		string mi;
		print("欢迎来到开发者模式");
		cout << "请输入密码: ";
		cout.flush();
		getline(mi);
		//if(to_hash(mi) == 12386266893725306769ull){
		if(mi == "123456"){
			hack();
		}else{
			lower_hack();
		}
	}
}
namespace setting{
	void setting(){
		print((string)"1.更改输出倍速, 2.自动钓鱼机开关(目前:"+(variate::auto_fishing?"开":"关")+") , 3.退出");
		print("当前输出倍速: " + to_string(variate::spead) + "(最大1000)");
		while(true){
			char c = getch();
			if(c == '1'){
				int s = 0;
				while(true){
					char d = getch();
					if(isdigit(d)){
						s *= 10;
						s += d ^ '0';
						if(s > 1000){
							s = 1000;
						}
						cout << "\r          \r" << s;
						cout.flush();
					}else if(d == 127){
						s /= 10;
						cout << "\r          \r" << s;
						cout.flush();
					}else if(d == '\r'){
						break;
					}
				}
				variate::spead = s;
				return;
			}else if(c == '2'){
				if(variate::open_fishing==false)
				{
					print("未拥有");
					break;
				}
				variate::auto_fishing=!variate::auto_fishing;
				print(variate::auto_fishing?"已开启":"已关闭");
				break;
			}else if(c == '3'){
				return;
			}
		}
	}
	void sys(int st=true){
		variate::spead = 1000;
		for(int i=0;i<=24;i++)
		{
			print(" ________________________");
			print("|    auto_fish system    |");
			print("|                        |");
			print("|      loading...        |");
			print("|                        |");
			string s=color::GREEN;
			for(int j=1;j<i;j++)s+="=";
			s+=color::NONE;
			for(int j=i;j<=24;j++)s+='-';
			print("|"+s+"|");
			print("|________________________|");
			system("sleep 0.1");
			clear();
		}
		if(variate::statu == 0){
			print(" ________________________");
			print("|    auto_fish system    |");
			print("|                        |");
			print("|      loading...        |");
			print("|                        |");
			print("|      verfity...        |");
			print("|________________________|");
			system("sleep 0.3");
			clear();
			print(" ________________________");
			print("|    auto_fish system    |");
			print("|                        |");
			print("|      loading...        |");
			print("|                        |");
			print("|  \033[31merror:missing key.pem\033[0m |");
			print("|________________________|");
			system("sleep 0.7");
			clear();
			variate::spead = 2;
			return;
		}
		variate::spead = 2;
		if(st)setting();
	}
}
int main(){
	srand(time(0));
	system("stty raw");
	system("stty -echo");
	clear();
	variate::time0=time(0);
	variate::spead = 1000;
	print(" ________________________ ",0);
	print("|    auto_fish system    |",0);
	print("|                        |",0);
	print("|      loading...        |",0);
	print("|                        |",0);
	print("|                        |",0);
	print("|________________________|",0);
	system("sleep 0.7");
	clear();
	string Name="";
	while(true)
	{
		clear();	
		print(" ________________________ ");
		print("|    auto_fish system    |");
		print("|                        |");
		print("| Please enter your name |");
		print("|                        |");
		string output=color::BLUE+Name+color::NONE;
		while(output.size()<22+string(color::BLUE+color::NONE).size())output+=' ';
		print("| "+output+" |");
		print("|________________________|");
		char c=getch();
		if((issymbol(c)||c<32)&&c!='\r'&&c!=127)continue;
		if(Name.size()<22&&c!='\r')Name+=c;
		if(c==127&&Name.size())Name=Name.substr(0,Name.size()-1);
		if(c=='\r'){
			checkpoint::readchpnp(Name);
			break;
		}
	}
	variate::username=Name;
	clear();
	setting::sys(false);
	printa("欢迎来到自助钓鱼系统。");
	printa("你可以在这里钓鱼。");
	printa("升级装备可以让钓鱼效率更高。");
	while(true){
		clear();
		print((string)"1.开始钓鱼, 2.升级, 3.使用道具, 7.开发者模式, 8."+(variate::statu>=2?"\033[36m":"\033[31m")+"auto_fish system\033[0m, 9.退出, 其他输入无效。");
		print("只用输入编号", 0.01);
		while(true){
			char type = getch();
			if(!islower(type) && !isupper(type) && !isdigit(type) && !issymbol(type) && type != '\r'){
				continue;
			}
			if(type == '1'){
				clear();
				fishing::fishing();
				sleep(0.5);
				break;
			}else if(type == '2'){
				clear();
				shop::shop();
				break;
			}else if(type == '3'){
				clear();
				shop::use();
				break;
			}else if(type == '7'){
				clear();
				tool::developer();
				break;
			}else if(type == '8'){
				clear();
				setting::sys();
				break;
			}else if(type == '9'){
				clear();
				system("stty cooked");
				system("stty echo");
				return 0;
			}
		}
		checkpoint::savechpnp(variate::username,false);
		shop::check_fishing();
		checkpoint::auto_save();
		sleep(1);
	}
}